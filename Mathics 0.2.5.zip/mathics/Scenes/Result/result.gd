extends Control

@onready var back_button: Button = %BackButton

var game_data: GameData = GM.load_game_data()

func _ready() -> void:
	back_button.pressed.connect(_on_back_button_pressed)

func _on_back_button_pressed():
	get_tree().change_scene_to_file("uid://utn7rxmrcfoh")
