extends Control

# Theme Palette Matching Mathics UI
const DARK_NEUTRAL := Color("111010")      # Scene background
const SURFACE_DARK := Color("1E2530")       # Default card background
const SURFACE_ACTIVE := Color("233142")     # Selected card background
const WISDOM_BLUE := Color("337AB7")        # Primary accent / border color
const KNOWLEDGE_GREEN := Color("2ECC71")    # Active check accent
const TEXT_LIGHT := Color("F7FAFC")         # Header / active text
const TEXT_MUTED := Color("718096")         # Subtitle / unselected text

@onready var bg: ColorRect = %BG
@onready var topic_list_container: VBoxContainer = %TopicListContainer
@onready var select_all_button: Button = %SelectAllButton
@onready var deselect_all_button: Button = %DeselectAllButton
@onready var start_quiz_button: Button = %StartQuizButton

var game_data: GameData

const TOPIC_DETAILS: Dictionary = {
	GM.TOPIC.POLYGON_PROPERTIES: {"name": "Polygon Properties", "icon": "📐"},
	GM.TOPIC.PYRAMID_VOLUME:     {"name": "Pyramid Volume",     "icon": "🔺"},
	GM.TOPIC.CYLINDER_VOLUME:    {"name": "Cylinder Volume",    "icon": "🛢"},
	GM.TOPIC.UNIT_CONVERSION:    {"name": "Unit Conversion",    "icon": "📏"},
	GM.TOPIC.PERCENTILE_CHANGES: {"name": "Percentile Changes", "icon": "📊"},
	GM.TOPIC.FINANCIAL_LITERACY: {"name": "Financial Literacy", "icon": "💰"},
	GM.TOPIC.SPEED_RATE:         {"name": "Speed & Rate",         "icon": "⚡"}
}

var button_map: Dictionary = {} # Maps GM.TOPIC to Button instance

func _ready() -> void:
	game_data = GM.load_game_data()
	
	_setup_labels_and_buttons()
	_populate_topic_list()
	_connect_action_buttons()
	_update_start_button_state()
	
	# Wait one frame so VBoxContainer finishes sorting layout before running entrance animation
	await get_tree().process_frame
	_animate_entrance()

func _setup_labels_and_buttons() -> void:
	select_all_button.text = "Select All"
	deselect_all_button.text = "Deselect All"
	start_quiz_button.text = "Start Quiz"
	
	bg.color = DARK_NEUTRAL
	_style_action_button(select_all_button, SURFACE_DARK, WISDOM_BLUE)
	_style_action_button(deselect_all_button, SURFACE_DARK, WISDOM_BLUE)
	_style_action_button(start_quiz_button, WISDOM_BLUE, WISDOM_BLUE)

func _update_card_visuals(btn: Button, name_str: String, icon_str: String, is_active: bool) -> void:
	var check_mark: String = "  [✓]  " if is_active else "  [  ]  "
	btn.text = check_mark + icon_str + "  " + name_str
	btn.add_theme_color_override("font_color", TEXT_LIGHT if is_active else TEXT_MUTED)
	
	var style_normal := StyleBoxFlat.new()
	style_normal.bg_color = SURFACE_ACTIVE if is_active else SURFACE_DARK
	style_normal.border_width_left = 2
	style_normal.border_width_top = 2
	style_normal.border_width_right = 2
	style_normal.border_width_bottom = 2
	style_normal.border_color = KNOWLEDGE_GREEN if is_active else Color("2A3442")
	style_normal.corner_radius_top_left = 10
	style_normal.corner_radius_top_right = 10
	style_normal.corner_radius_bottom_left = 10
	style_normal.corner_radius_bottom_right = 10
	style_normal.content_margin_left = 12
	style_normal.content_margin_right = 12
	
	var style_hover := style_normal.duplicate() as StyleBoxFlat
	style_hover.bg_color = style_normal.bg_color.lerp(WISDOM_BLUE, 0.2)
	style_hover.border_color = WISDOM_BLUE
	
	btn.add_theme_stylebox_override("normal", style_normal)
	btn.add_theme_stylebox_override("hover", style_hover)
	btn.add_theme_stylebox_override("pressed", style_normal)
	btn.add_theme_stylebox_override("focus", style_normal)

func _animate_press(btn: Button) -> void:
	btn.pivot_offset = btn.size / 2.0
	var tween := create_tween()
	tween.tween_property(btn, "scale", Vector2(0.97, 0.97), 0.04)
	tween.tween_property(btn, "scale", Vector2(1.0, 1.0), 0.08).set_trans(Tween.TRANS_SPRING)

func _on_topic_toggled(topic_enum: GM.TOPIC, is_pressed: bool) -> void:
	if is_pressed and not game_data.selected_topics.has(topic_enum):
		game_data.selected_topics.append(topic_enum)
	elif not is_pressed and game_data.selected_topics.has(topic_enum):
		game_data.selected_topics.erase(topic_enum)
	
	_update_start_button_state()

func _sync_selected_topics_to_gamedata() -> void:
	game_data.selected_topics.clear()
	
	for topic_enum in button_map.keys():
		var btn: Button = button_map[topic_enum]
		if btn.get_meta("is_selected", false):
			game_data.selected_topics.append(topic_enum)
	
	# Dynamically set max questions: 5 questions per selected topic
	const QUESTIONS_PER_TOPIC := 5
	game_data.max_questions = game_data.selected_topics.size() * QUESTIONS_PER_TOPIC
	
	_update_start_button_state()

func _connect_action_buttons() -> void:
	select_all_button.pressed.connect(func():
		for topic_enum in button_map.keys():
			var btn: Button = button_map[topic_enum]
			btn.set_meta("is_selected", true)
			var details: Dictionary = TOPIC_DETAILS[topic_enum]
			_update_card_visuals(btn, details["name"], details["icon"], true)
		_sync_selected_topics_to_gamedata()
	)
	
	deselect_all_button.pressed.connect(func():
		for topic_enum in button_map.keys():
			var btn: Button = button_map[topic_enum]
			btn.set_meta("is_selected", false)
			var details: Dictionary = TOPIC_DETAILS[topic_enum]
			_update_card_visuals(btn, details["name"], details["icon"], false)
		_sync_selected_topics_to_gamedata()
	)
	start_quiz_button.pressed.connect(_on_start_quiz_pressed)

func _update_start_button_state() -> void:
	var has_selection: bool = game_data.selected_topics.size() > 0
	start_quiz_button.disabled = not has_selection
	
	var tween := create_tween()
	tween.tween_property(start_quiz_button, "modulate:a", 1.0 if has_selection else 0.4, 0.15)
	GM.save_game_data(game_data)

func _on_start_quiz_pressed() -> void:
	if game_data.selected_topics.size() > 0:
		get_tree().change_scene_to_file("uid://bf5vi0tw50kus")

func _style_action_button(btn: Button, bg_col: Color, border_col: Color) -> void:
	if not btn: return
	btn.custom_minimum_size.y = 50
	btn.add_theme_font_size_override("font_size", 16)
	btn.add_theme_color_override("font_color", TEXT_LIGHT)
	btn.pivot_offset = btn.size / 2.0
	btn.resized.connect(func(): btn.pivot_offset = btn.size / 2.0)
	
	var style_normal := StyleBoxFlat.new()
	style_normal.bg_color = bg_col
	style_normal.border_width_left = 2
	style_normal.border_width_top = 2
	style_normal.border_width_right = 2
	style_normal.border_width_bottom = 2
	style_normal.border_color = border_col
	style_normal.corner_radius_top_left = 10
	style_normal.corner_radius_top_right = 10
	style_normal.corner_radius_bottom_left = 10
	style_normal.corner_radius_bottom_right = 10
	
	var style_hover := style_normal.duplicate() as StyleBoxFlat
	style_hover.bg_color = bg_col.lerp(border_col, 0.25)
	
	btn.add_theme_stylebox_override("normal", style_normal)
	btn.add_theme_stylebox_override("hover", style_hover)
	btn.add_theme_stylebox_override("pressed", style_normal)
	btn.add_theme_stylebox_override("focus", style_normal)
	
	btn.button_down.connect(func():
		var tween := create_tween()
		tween.tween_property(btn, "scale", Vector2(0.96, 0.96), 0.04)
	)
	btn.button_up.connect(func():
		var tween := create_tween()
		tween.tween_property(btn, "scale", Vector2(1.0, 1.0), 0.08).set_trans(Tween.TRANS_SPRING)
	)

# FIXED ENTRANCE ANIMATION: Does not modify position.y inside layout container
func _populate_topic_list() -> void:
	for child in topic_list_container.get_children():
		child.queue_free()
	
	button_map.clear()

	for topic_enum in TOPIC_DETAILS.keys():
		var details: Dictionary = TOPIC_DETAILS[topic_enum]
		
		# 1. Create a layout wrapper so VBoxContainer controls slot dimensions, not button position
		var wrapper := Control.new()
		wrapper.custom_minimum_size.y = 52
		wrapper.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		
		# 2. Create the actual styled card button
		var btn := Button.new()
		btn.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT) # Fill wrapper area
		btn.add_theme_font_size_override("font_size", 16)
		btn.alignment = HORIZONTAL_ALIGNMENT_LEFT
		
		# Set pivot offset for click press scaling
		btn.pivot_offset = btn.size / 2.0
		btn.resized.connect(func(): btn.pivot_offset = btn.size / 2.0)
		
		var is_selected: bool = game_data.selected_topics.has(topic_enum) or game_data.selected_topics.is_empty()
		btn.set_meta("is_selected", is_selected)
		
		_update_card_visuals(btn, details["name"], details["icon"], is_selected)
		
		btn.pressed.connect(func():
			var current_state: bool = btn.get_meta("is_selected")
			var new_state := not current_state
			btn.set_meta("is_selected", new_state)
			
			_update_card_visuals(btn, details["name"], details["icon"], new_state)
			_animate_press(btn)
			_on_topic_toggled(topic_enum, new_state)
		)
		
		wrapper.add_child(btn)
		topic_list_container.add_child(wrapper)
		button_map[topic_enum] = btn
	
	_sync_selected_topics_to_gamedata()

# Slide-in cascade entrance animation
func _animate_entrance() -> void:
	# Hide list briefly to allow VBoxContainer to calculate initial layout frame
	topic_list_container.modulate.a = 0.0
	await get_tree().process_frame
	await get_tree().process_frame
	topic_list_container.modulate.a = 1.0
	
	var delay: float = 0.0
	for wrapper in topic_list_container.get_children():
		if wrapper.get_child_count() == 0: 
			continue
		
		var btn := wrapper.get_child(0) as Button
		if not btn: 
			continue
		
		# Start offset to the left and invisible
		btn.position.x = -60.0
		btn.modulate.a = 0.0
		
		# Smooth slide in from left to origin (0) with ease-out spring
		var tween := create_tween()
		tween.set_parallel(true)
		tween.tween_property(btn, "position:x", 0.0, 0.25).set_delay(delay).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
		tween.tween_property(btn, "modulate:a", 1.0, 0.20).set_delay(delay)
		
		delay += 0.04
