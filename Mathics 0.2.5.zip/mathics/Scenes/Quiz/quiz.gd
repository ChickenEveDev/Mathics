extends Control

#region Constants
# Corrected Font Auto-Sizing Bounds
const MIN_FONT_SIZE: int = 14
const MAX_FONT_SIZE: int = 32

# Mathics Palette Colors
const DARK_NEUTRAL := Color("111010")      # Background
const SURFACE_DARK := Color("1E2530")       # Panels / Surfaces
const WISDOM_BLUE := Color("337AB7")        # Category Badge / Primary Accent
const KNOWLEDGE_GREEN := Color("5CB85C")    # Easy Mastery / Progress Fill
const CURIOSITY_YELLOW := Color("F0AD4E")   # Medium Mastery
const INNOVATION_PURPLE := Color("8A6ACD")  # Hard / Master Level
const TEXT_LIGHT := Color("F7FAFC")         # Primary text
const TEXT_MUTED := Color("A0AEC0")         # Secondary tracker text

const QUESTIONS_PER_TOPIC: int = 5
#endregion

#region Variables
var game_data: GameData

# UI References
@onready var background: ColorRect = $BG
@onready var question_container: PanelContainer = %QuestionContainer
@onready var question_text: Label = %QuestionText
@onready var question_image: Control = %QuestionImage

@onready var choice_a: Button = %ChoiceA
@onready var choice_b: Button = %ChoiceB
@onready var choice_c: Button = %ChoiceC
@onready var choice_d: Button = %ChoiceD

@onready var category_badge: PanelContainer = %CategoryBadge
@onready var category_label: Label = %CategoryLabel

@onready var mastery_badge: PanelContainer = %MasteryBadge
@onready var mastery_label: Label = %MasteryLabel

@onready var question_tracker_label: Label = %QuestionTrackerLabel
@onready var quiz_progress_bar: ProgressBar = %QuizProgressBar

# Question State
var max_question: int = 5
var correct_answer_index: int = -1
var topic_selected: GM.TOPIC
var topic_queue: Array[GM.TOPIC] = []
var tier: GM.MASTERY_TIER = GM.MASTERY_TIER.SILVER
var current_question_number: int = 1
var correct_answer: String = ""
var correct_answer_counter: int = 0

var choice_buttons: Array[Button] = []
#endregion

func _ready() -> void:
	game_data = GM.load_game_data()
	
	# Clear session duplicate tracking list at start
	if game_data != null:
		game_data.generated_question_list.clear()
	
	_setup_topic_queue()
	
	choice_buttons = [choice_a, choice_b, choice_c, choice_d]
	
	# 1. Apply UI Layout & Stylebox Theme Overrides
	_apply_quiz_styling()
	_setup_button_juice()
	
	# 2. Hook Question Text Resize Signals
	_initialize_question_text()
	
	# 3. Connect Choice Buttons & Load First Question
	setup_choice_buttons()
	load_next_question()

func _setup_topic_queue() -> void:
	topic_queue.clear()
	
	if game_data != null and not game_data.selected_topics.is_empty():
		for topic in game_data.selected_topics:
			for i in range(QUESTIONS_PER_TOPIC):
				topic_queue.append(topic)
		
		# Set total max questions dynamically (5 per chosen topic)
		max_question = topic_queue.size()
		
		# Shuffle topic queue so questions from selected topics are mixed
		topic_queue.shuffle()
	else:
		# Fallback if no topics were passed in game_data
		for i in range(QUESTIONS_PER_TOPIC):
			topic_queue.append(GM.TOPIC.POLYGON_PROPERTIES)
		max_question = QUESTIONS_PER_TOPIC

#region Header & Theme Styling
func setup_quiz_header(category_name: String, difficulty: String, current_q: int, total_q: int) -> void:
	# 1. Update Category
	if category_label:
		category_label.text = category_name.to_upper()
		
	# 2. Update Mastery / Difficulty Badge Color
	if mastery_label and mastery_badge:
		mastery_label.text = difficulty.to_upper()
		_style_badge(mastery_badge, _get_mastery_color(difficulty))
		
	# 3. Update Progress Tracker & Animated Progress Bar
	if question_tracker_label:
		question_tracker_label.text = "%d / %d" % [current_q, total_q]
		
	if quiz_progress_bar:
		var target_percent: float = (float(current_q) / float(total_q)) * 100.0
		var tween := create_tween()
		tween.tween_property(quiz_progress_bar, "value", target_percent, 0.25).set_trans(Tween.TRANS_SINE)

func _get_mastery_color(difficulty: String) -> Color:
	match difficulty.to_lower():
		"easy", "silver":
			return KNOWLEDGE_GREEN
		"medium", "gold":
			return CURIOSITY_YELLOW
		"hard", "expert", "diamond":
			return INNOVATION_PURPLE
		_:
			return WISDOM_BLUE

func _apply_quiz_styling() -> void:
	if background:
		background.color = DARK_NEUTRAL
		
	# Style Header Elements
	if category_badge:
		_style_badge(category_badge, WISDOM_BLUE)
	if category_label:
		category_label.add_theme_color_override("font_color", TEXT_LIGHT)
		category_label.add_theme_font_size_override("font_size", 12)

	if mastery_label:
		mastery_label.add_theme_color_override("font_color", TEXT_LIGHT)
		mastery_label.add_theme_font_size_override("font_size", 12)

	if question_tracker_label:
		question_tracker_label.add_theme_color_override("font_color", TEXT_MUTED)
		question_tracker_label.add_theme_font_size_override("font_size", 14)

	if quiz_progress_bar:
		quiz_progress_bar.show_percentage = false
		quiz_progress_bar.custom_minimum_size.y = 8
		
		var bg_style := StyleBoxFlat.new()
		bg_style.bg_color = SURFACE_DARK
		bg_style.corner_radius_top_left = 4
		bg_style.corner_radius_top_right = 4
		bg_style.corner_radius_bottom_left = 4
		bg_style.corner_radius_bottom_right = 4
		
		var fill_style := StyleBoxFlat.new()
		fill_style.bg_color = KNOWLEDGE_GREEN
		fill_style.corner_radius_top_left = 4
		fill_style.corner_radius_top_right = 4
		fill_style.corner_radius_bottom_left = 4
		fill_style.corner_radius_bottom_right = 4
		
		quiz_progress_bar.add_theme_stylebox_override("background", bg_style)
		quiz_progress_bar.add_theme_stylebox_override("fill", fill_style)

	# Question Container Panel Style (Single clean border)
	if question_container:
		var q_style := StyleBoxFlat.new()
		q_style.bg_color = SURFACE_DARK
		q_style.border_width_left = 2
		q_style.border_width_top = 2
		q_style.border_width_right = 2
		q_style.border_width_bottom = 2
		q_style.border_color = WISDOM_BLUE
		q_style.corner_radius_top_left = 16
		q_style.corner_radius_top_right = 16
		q_style.corner_radius_bottom_left = 16
		q_style.corner_radius_bottom_right = 16
		q_style.content_margin_left = 20
		q_style.content_margin_right = 20
		q_style.content_margin_top = 24
		q_style.content_margin_bottom = 24
		question_container.add_theme_stylebox_override("panel", q_style)

	if question_text:
		question_text.add_theme_color_override("font_color", TEXT_LIGHT)

	# Choice Buttons with Palette Colors
	var palette_colors: Array[Color] = [
		WISDOM_BLUE,        # Choice A Accent
		KNOWLEDGE_GREEN,    # Choice B Accent
		CURIOSITY_YELLOW,   # Choice C Accent
		INNOVATION_PURPLE   # Choice D Accent
	]
	
	for i in range(choice_buttons.size()):
		var btn: Button = choice_buttons[i]
		if btn:
			var accent_col: Color = palette_colors[i % palette_colors.size()]
			_style_choice_button(btn, SURFACE_DARK, accent_col)

func _style_choice_button(btn: Button, bg_col: Color, border_col: Color) -> void:
	btn.custom_minimum_size.y = 70
	btn.add_theme_font_size_override("font_size", 18)
	btn.add_theme_color_override("font_color", TEXT_LIGHT)
	btn.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	
	# Base / Normal State Style
	var style_normal := StyleBoxFlat.new()
	style_normal.bg_color = bg_col
	style_normal.border_width_left = 3
	style_normal.border_width_top = 3
	style_normal.border_width_right = 3
	style_normal.border_width_bottom = 3
	style_normal.border_color = border_col
	style_normal.corner_radius_top_left = 12
	style_normal.corner_radius_top_right = 12
	style_normal.corner_radius_bottom_left = 12
	style_normal.corner_radius_bottom_right = 12

	# Hover State
	var style_hover := style_normal.duplicate() as StyleBoxFlat
	style_hover.bg_color = bg_col.lerp(border_col, 0.25)
	style_hover.border_color = border_col.lightened(0.2)

	# Pressed State
	var style_pressed := style_normal.duplicate() as StyleBoxFlat
	style_pressed.bg_color = border_col
	style_pressed.border_color = border_col.lightened(0.3)

	# Focus State
	var style_focus := style_hover.duplicate() as StyleBoxFlat

	# Apply StyleBoxes to Button Theme Overrides
	btn.add_theme_stylebox_override("normal", style_normal)
	btn.add_theme_stylebox_override("hover", style_hover)
	btn.add_theme_stylebox_override("pressed", style_pressed)
	btn.add_theme_stylebox_override("focus", style_focus)
	btn.add_theme_stylebox_override("disabled", style_normal.duplicate())

func _style_badge(badge: PanelContainer, border_color: Color) -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = SURFACE_DARK
	style.border_width_left = 1
	style.border_width_top = 1
	style.border_width_right = 1
	style.border_width_bottom = 1
	style.border_color = border_color
	style.corner_radius_top_left = 6
	style.corner_radius_top_right = 6
	style.corner_radius_bottom_left = 6
	style.corner_radius_bottom_right = 6
	style.content_margin_left = 8
	style.content_margin_right = 8
	style.content_margin_top = 4
	style.content_margin_bottom = 4
	badge.add_theme_stylebox_override("panel", style)

func _setup_button_juice() -> void:
	for btn in choice_buttons:
		if not btn: 
			continue
		
		btn.pivot_offset = btn.size / 2.0
		
		if not btn.resized.is_connected(_on_button_resized):
			btn.resized.connect(_on_button_resized.bind(btn))
		
		btn.button_down.connect(func():
			var tween := create_tween()
			tween.tween_property(btn, "scale", Vector2(0.96, 0.96), 0.05)
		)
		
		btn.button_up.connect(func():
			var tween := create_tween()
			tween.tween_property(btn, "scale", Vector2(1.0, 1.0), 0.08).set_trans(Tween.TRANS_SPRING)
		)

func _on_button_resized(btn: Button) -> void:
	btn.pivot_offset = btn.size / 2.0
#endregion

#region Question Flow
func roll_tier() -> void:
	if game_data == null or not game_data.competency_tier.has(topic_selected):
		tier = GM.MASTERY_TIER.SILVER
		return

	var roll: float = randf() * 100.0
	match game_data.competency_tier[topic_selected]:
		GM.MASTERY_TIER.SILVER:
			tier = GM.MASTERY_TIER.SILVER

		GM.MASTERY_TIER.GOLD:
			if roll < 75.0:
				tier = GM.MASTERY_TIER.GOLD
			elif roll < 93.75:
				tier = GM.MASTERY_TIER.SILVER
			else:
				tier = GM.MASTERY_TIER.DIAMOND

		GM.MASTERY_TIER.DIAMOND:
			if roll < 75.0:
				tier = GM.MASTERY_TIER.DIAMOND
			elif roll < 93.75:
				tier = GM.MASTERY_TIER.GOLD
			else:
				tier = GM.MASTERY_TIER.SILVER

		_:
			tier = GM.MASTERY_TIER.SILVER

func load_next_question() -> void:
	if topic_queue.is_empty():
		return
		
	topic_selected = topic_queue.pop_front()
	
	var new_question: Dictionary
	var max_attempts: int = 100
	var attempts: int = 0
	
	roll_tier()
	
	while attempts < max_attempts:
		attempts += 1
		match topic_selected:
			GM.TOPIC.UNIT_CONVERSION:
				new_question = UnitConversionGenerator.generate_question(tier)
			GM.TOPIC.PYRAMID_VOLUME:
				new_question = PyramidVolumeGenerator.generate_question(tier)
			GM.TOPIC.CYLINDER_VOLUME:
				new_question = CylinderVolumeGenerator.generate_question(tier)
			GM.TOPIC.PERCENTILE_CHANGES:
				new_question = PercentileChangesGenerator.generate_question(tier)
			GM.TOPIC.FINANCIAL_LITERACY:
				new_question = FinancialLiteracyGenerator.generate_question(tier)
			GM.TOPIC.SPEED_RATE:
				new_question = SpeedRateGenerator.generate_question(tier)
			GM.TOPIC.POLYGON_PROPERTIES:
				new_question = PolygonPropertiesGenerator.generate_question(tier)
		
		if new_question.is_empty():
			continue
			
		var q_text: String = new_question.get("question_text", new_question.get("question", ""))
		
		if game_data != null and game_data.generated_question_list.has(q_text):
			continue
			
		if game_data != null and not q_text.is_empty():
			game_data.generated_question_list.append(q_text)
			
		break
	
	if new_question.is_empty():
		return
	
	display_question(new_question)

func display_question(new_question: Dictionary) -> void:
	var q_text: String = new_question.get("question_text", new_question.get("question", ""))
	set_question_text(q_text)
	
	choice_a.text = str(new_question["choices"][0])
	choice_b.text = str(new_question["choices"][1])
	choice_c.text = str(new_question["choices"][2])
	choice_d.text = str(new_question["choices"][3])
	
	# Find exact index of correct answer inside choices array
	var raw_correct = new_question["correct_answer"]
	correct_answer_index = new_question["choices"].find(raw_correct)
	
	# Fallback string comparison in case find() fails
	if correct_answer_index == -1:
		for i in range(new_question["choices"].size()):
			if str(new_question["choices"][i]).strip_edges() == str(raw_correct).strip_edges():
				correct_answer_index = i
				break
	
	var topic_str: String = GM.TOPIC.keys()[topic_selected].capitalize()
	var tier_str: String = GM.MASTERY_TIER.keys()[tier].capitalize()
	setup_quiz_header(topic_str, tier_str, current_question_number, max_question)

func setup_choice_buttons() -> void:
	if not choice_a.pressed.is_connected(_on_choice_pressed):
		choice_a.pressed.connect(_on_choice_pressed.bind(choice_a))
		choice_b.pressed.connect(_on_choice_pressed.bind(choice_b))
		choice_c.pressed.connect(_on_choice_pressed.bind(choice_c))
		choice_d.pressed.connect(_on_choice_pressed.bind(choice_d))

func _on_choice_pressed(button: Button) -> void:
	_set_buttons_enabled(false)
	
	var chosen_index: int = choice_buttons.find(button)
	var is_correct: bool = (chosen_index == correct_answer_index)
	
	if is_correct:
		correct_answer_counter += 1
	
	_show_answer_feedback(chosen_index, is_correct)
	
	await get_tree().create_timer(0.8).timeout
	
	_reset_button_styles()
	_set_buttons_enabled(true)
	
	current_question_number += 1

	if current_question_number <= max_question:
		load_next_question()
	else:
		if game_data != null:
			game_data.generated_question_list.clear()
		get_tree().change_scene_to_file("uid://5q1rgn0x57hu")

func _show_answer_feedback(chosen_index: int, is_correct: bool) -> void:
	var green_style := StyleBoxFlat.new()
	green_style.bg_color = Color("2ECC71") # Bright Green
	green_style.set_corner_radius_all(12)
	
	var red_style := StyleBoxFlat.new()
	red_style.bg_color = Color("E74C3C")   # Bright Red
	red_style.set_corner_radius_all(12)

	for i in range(choice_buttons.size()):
		var btn: Button = choice_buttons[i]
		if not btn: 
			continue
		
		btn.release_focus()

		if i == chosen_index:
			# Clicked button gets Green if correct, Red if wrong
			var style := green_style if is_correct else red_style
			_apply_style_to_all_states(btn, style)
		elif not is_correct and i == correct_answer_index:
			# If wrong, show the actual correct choice in Green
			_apply_style_to_all_states(btn, green_style)
		else:
			# Unselected choices dim out
			btn.modulate.a = 0.4

func _apply_style_to_all_states(btn: Button, style: StyleBox) -> void:
	btn.add_theme_stylebox_override("normal", style.duplicate())
	btn.add_theme_stylebox_override("hover", style.duplicate())
	btn.add_theme_stylebox_override("pressed", style.duplicate())
	btn.add_theme_stylebox_override("focus", style.duplicate())
	btn.add_theme_stylebox_override("disabled", style.duplicate())

func _set_buttons_enabled(enabled: bool) -> void:
	for btn in choice_buttons:
		if btn:
			btn.disabled = not enabled

func _reset_button_styles() -> void:
	for btn in choice_buttons:
		if btn:
			btn.modulate.a = 1.0
	_apply_quiz_styling()
#endregion

#region Font Auto-Fit
func set_question_text(new_text: String) -> void:
	question_text.text = new_text
	call_deferred("_adjust_font_size")

func _initialize_question_text() -> void:
	question_text.resized.connect(_adjust_font_size)
	question_text.item_rect_changed.connect(_adjust_font_size)

func _adjust_font_size() -> void:
	if question_text.text.is_empty() or question_text.size.x <= 0 or question_text.size.y <= 0:
		return
	
	var font = question_text.get_theme_font("font")
	var font_size = MAX_FONT_SIZE
	
	while font_size > MIN_FONT_SIZE:
		var text_size = font.get_string_size(question_text.text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
		if text_size.x <= question_text.size.x and text_size.y <= question_text.size.y:
			break
		font_size -= 1
	
	question_text.add_theme_font_size_override("font_size", font_size)
#endregion
