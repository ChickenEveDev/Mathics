extends Node

#region Constants
# Mathics Dark Palette Colors
const DARK_NEUTRAL := Color("111010")      # Main background
const SURFACE_DARK := Color("1E2530")       # Option overlay & panel surface
const WISDOM_BLUE := Color("337AB7")        # Primary brand / option buttons
const KNOWLEDGE_GREEN := Color("5CB85C")    # Main action / enter button
const INNOVATION_PURPLE := Color("8A6ACD")  # Secondary buttons (Close)
const CURIOSITY_YELLOW := Color("F0AD4E")   # Highlights / Sliders / Warnings
const TEXT_LIGHT := Color("F7FAFC")         # Crisp body text
const TEXT_MUTED := Color("A0AEC0")         # Subtitles / secondary labels
#endregion

#region Variables
# Main Title UI
@onready var game_title: Label = %GameTitle
@onready var enter_button: Button = %EnterButton
@onready var option_button: Button = %OptionButton
@onready var quit_button: Button = %QuitButton

@onready var cheat_warning_label: Label = %CheatWarningLabel
@onready var background: ColorRect = %Background

# Audio
@onready var audio_stream_player_bgm: AudioStreamPlayer = %AudioStreamPlayer_BGM

# Option Overlay UI
@onready var option_overlay: ColorRect = %OptionOverlay
@onready var close_button: Button = %CloseButton

@onready var master_volume_h_slider: HSlider = %MasterVolumeHSlider
@onready var music_volume_h_slider: HSlider = %MusicVolumeHSlider
@onready var sfx_volume_h_slider: HSlider = %SFXVolumeHSlider

var game_data: GameData
var _overlay_panel: PanelContainer
var title_buttons: Array[Button] = []
#endregion

func _ready() -> void:
	# 1. UI signals
	enter_button.pressed.connect(_on_enter_pressed)
	option_button.pressed.connect(_on_option_pressed)
	quit_button.pressed.connect(_on_quit_pressed)
	close_button.pressed.connect(_on_close_pressed)
	
	# 2. Slider signals
	master_volume_h_slider.value_changed.connect(_on_master_volume_changed)
	music_volume_h_slider.value_changed.connect(_on_music_volume_changed)
	sfx_volume_h_slider.value_changed.connect(_on_sfx_volume_changed)
	
	# 3. Locate Overlay Panel for animations
	if option_overlay.has_node("PanelContainer"):
		_overlay_panel = option_overlay.get_node("PanelContainer")
	
	# 4. Apply Dark UI Styling
	_apply_ui_styling()
	
	# 5. Connect UI Juice (Hover/Click animations)
	title_buttons = [enter_button, option_button, quit_button, close_button]
	_setup_title_button_juice()
	_setup_button_juice(enter_button)
	_setup_button_juice(option_button)
	_setup_button_juice(quit_button)
	_setup_button_juice(close_button)
	
	option_overlay.visible = false
	cheat_warning_label.text = ""
	
	_initialize_game_state()
	
	if game_data.is_first_time:
		_initialize_tutorial()

func _initialize_tutorial() -> void:
	pass

func _initialize_game_state() -> void:
	game_data = GM.load_game_data()
	
	# Update sliders from saved data
	master_volume_h_slider.value = game_data.master_volume
	music_volume_h_slider.value = game_data.music_volume
	sfx_volume_h_slider.value = game_data.sfx_volume
	
	# Apply initial audio bus volumes
	set_bus_volume("Master", game_data.master_volume)
	set_bus_volume("Music", game_data.music_volume)
	set_bus_volume("SFX", game_data.sfx_volume)
	
	# Play BGM with smooth fade-in juice
	if !audio_stream_player_bgm.playing:
		audio_stream_player_bgm.stream = load("res://Audio/BGM/Sunlight_Through_the_Canopy.mp3")
		audio_stream_player_bgm.volume_db = -80.0
		audio_stream_player_bgm.play()
		var tween = create_tween()
		tween.tween_property(audio_stream_player_bgm, "volume_db", 0.0, 1.5)
	
	# Anti-cheat check with highlighted warning style
	var current_time: int = int(Time.get_unix_time_from_system())
	if current_time < game_data.last_unix_timestamp:
		cheat_warning_label.text = "SYSTEM TIME ERROR! Fix clock to play"
		cheat_warning_label.add_theme_color_override("font_color", CURIOSITY_YELLOW)
		enter_button.disabled = true
	else:
		game_data.last_unix_timestamp = current_time
		GM.save_game_data(game_data)

#region Navigation
func _on_enter_pressed() -> void:
	# Juicy shrink-and-flash effect before scene transition
	var tween = create_tween().set_parallel(true)
	tween.tween_property(enter_button, "scale", Vector2(0.95, 0.95), 0.1)
	tween.tween_property(background, "color", Color.BLACK, 0.3)
	await tween.finished
	get_tree().change_scene_to_file("uid://60g42oaslglr")

func _on_option_pressed() -> void:
	option_overlay.visible = true
	option_overlay.modulate.a = 0.0
	
	var tween = create_tween().set_parallel(true)
	tween.tween_property(option_overlay, "modulate:a", 1.0, 0.2)
	
	# Pop-in bounce animation for option panel container
	if _overlay_panel:
		_overlay_panel.pivot_offset = _overlay_panel.size / 2.0
		_overlay_panel.scale = Vector2(0.8, 0.8)
		tween.tween_property(_overlay_panel, "scale", Vector2(1.0, 1.0), 0.35).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)

func _on_quit_pressed() -> void:
	var tween = create_tween()
	tween.tween_property(self, "modulate:a", 0.0, 0.2)
	await tween.finished
	get_tree().quit()

func _on_close_pressed() -> void:
	GM.save_game_data(game_data)
	var tween = create_tween().set_parallel(true)
	tween.tween_property(option_overlay, "modulate:a", 0.0, 0.2)
	if _overlay_panel:
		tween.tween_property(_overlay_panel, "scale", Vector2(0.8, 0.8), 0.2)
	await tween.finished
	option_overlay.visible = false

#endregion

#region Audio
func set_bus_volume(bus_name: String, value: float) -> void:
	var bus_index = AudioServer.get_bus_index(bus_name)
	if bus_index != -1:
		AudioServer.set_bus_volume_db(bus_index, linear_to_db(value))

func _on_master_volume_changed(value: float) -> void:
	game_data.master_volume = value
	set_bus_volume("Master", value)

func _on_music_volume_changed(value: float) -> void:
	game_data.music_volume = value
	set_bus_volume("Music", value)

func _on_sfx_volume_changed(value: float) -> void:
	game_data.sfx_volume = value
	set_bus_volume("SFX", value)
#endregion

#region UI & Juice
func _apply_ui_styling() -> void:
	# 1. Main Dark Background
	if background:
		background.color = DARK_NEUTRAL
	
	# 2. Options Overlay Background Dimming
	if option_overlay:
		option_overlay.color = Color(DARK_NEUTRAL.r, DARK_NEUTRAL.g, DARK_NEUTRAL.b, 0.85)
		if _overlay_panel:
			var panel_style := StyleBoxFlat.new()
			panel_style.bg_color = SURFACE_DARK
			panel_style.border_width_left = 3
			panel_style.border_width_top = 3
			panel_style.border_width_right = 3
			panel_style.border_width_bottom = 3
			panel_style.border_color = WISDOM_BLUE
			panel_style.corner_radius_top_left = 12
			panel_style.corner_radius_top_right = 12
			panel_style.corner_radius_bottom_left = 12
			panel_style.corner_radius_bottom_right = 12
			panel_style.content_margin_left = 20
			panel_style.content_margin_right = 20
			panel_style.content_margin_top = 20
			panel_style.content_margin_bottom = 20
			_overlay_panel.add_theme_stylebox_override("panel", panel_style)

	# 3. Game Title Styling
	if game_title:
		game_title.text = "MATHICS"
		game_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		game_title.add_theme_color_override("font_color", TEXT_LIGHT)
		game_title.add_theme_font_size_override("font_size", 38)

	# 4. Main Menu Buttons
	if enter_button:
		_style_button(enter_button, "ENTER GAME", KNOWLEDGE_GREEN)
	if option_button:
		_style_button(option_button, "OPTIONS", WISDOM_BLUE)
	if quit_button:
		_style_button(quit_button, "QUIT", SURFACE_DARK)
	if close_button:
		_style_button(close_button, "CLOSE", INNOVATION_PURPLE)

	# 5. Option Overlay Sliders & Labels Styling
	_style_slider(master_volume_h_slider)
	_style_slider(music_volume_h_slider)
	_style_slider(sfx_volume_h_slider)

func _style_button(btn: Button, text_val: String, accent_color: Color) -> void:
	btn.text = text_val
	btn.add_theme_font_size_override("font_size", 16)
	btn.add_theme_color_override("font_color", TEXT_LIGHT)
	
	var style_normal := StyleBoxFlat.new()
	style_normal.bg_color = SURFACE_DARK
	style_normal.border_width_left = 2
	style_normal.border_width_top = 2
	style_normal.border_width_right = 2
	style_normal.border_width_bottom = 2
	style_normal.border_color = accent_color
	style_normal.corner_radius_top_left = 8
	style_normal.corner_radius_top_right = 8
	style_normal.corner_radius_bottom_left = 8
	style_normal.corner_radius_bottom_right = 8
	
	var style_pressed := style_normal.duplicate() as StyleBoxFlat
	style_pressed.bg_color = accent_color
	
	btn.add_theme_stylebox_override("normal", style_normal)
	btn.add_theme_stylebox_override("hover", style_pressed)
	btn.add_theme_stylebox_override("pressed", style_pressed)
	btn.add_theme_stylebox_override("focus", style_normal)

func _style_slider(slider: HSlider) -> void:
	if not slider: return
	
	var grabber_style := StyleBoxFlat.new()
	grabber_style.bg_color = CURIOSITY_YELLOW
	grabber_style.corner_radius_top_left = 6
	grabber_style.corner_radius_top_right = 6
	grabber_style.corner_radius_bottom_left = 6
	grabber_style.corner_radius_bottom_right = 6
	grabber_style.expand_margin_top = 4
	grabber_style.expand_margin_bottom = 4
	
	var slider_area := StyleBoxFlat.new()
	slider_area.bg_color = DARK_NEUTRAL
	slider_area.corner_radius_top_left = 4
	slider_area.corner_radius_top_right = 4
	slider_area.corner_radius_bottom_left = 4
	slider_area.corner_radius_bottom_right = 4
	slider_area.content_margin_top = 6
	slider_area.content_margin_bottom = 6
	
	slider.add_theme_stylebox_override("slider", slider_area)
	slider.add_theme_stylebox_override("grabber_area", grabber_style)
	slider.add_theme_stylebox_override("grabber_area_highlight", grabber_style)

func _setup_button_juice(btn: Button) -> void:
	if not btn: return
	btn.pivot_offset = btn.size / 2.0
	
	btn.mouse_entered.connect(func():
		var tween = create_tween()
		tween.tween_property(btn, "scale", Vector2(1.05, 1.05), 0.1).set_trans(Tween.TRANS_SINE)
	)
	
	btn.mouse_exited.connect(func():
		var tween = create_tween()
		tween.tween_property(btn, "scale", Vector2(1.0, 1.0), 0.1).set_trans(Tween.TRANS_SINE)
	)
	
	btn.button_down.connect(func():
		var tween = create_tween()
		tween.tween_property(btn, "scale", Vector2(0.95, 0.95), 0.05)
	)
	
	btn.button_up.connect(func():
		var tween = create_tween()
		tween.tween_property(btn, "scale", Vector2(1.05, 1.05), 0.05)
	)

func _setup_title_button_juice() -> void:
	for btn in title_buttons:
		if not btn: 
			continue
		
		# Set initial pivot offset to button center
		btn.pivot_offset = btn.size / 2.0
		
		# Keep pivot centered dynamically if button size or text changes
		if not btn.resized.is_connected(_on_button_resized):
			btn.resized.connect(_on_button_resized.bind(btn))
		
		# Press down animation (scale down slightly)
		btn.button_down.connect(func():
			var tween := create_tween()
			tween.tween_property(btn, "scale", Vector2(0.95, 0.95), 0.05)
		)
		
		# Release animation (spring back to full size)
		btn.button_up.connect(func():
			var tween := create_tween()
			tween.tween_property(btn, "scale", Vector2(1.0, 1.0), 0.08).set_trans(Tween.TRANS_SPRING)
		)

func _on_button_resized(btn: Button) -> void:
	btn.pivot_offset = btn.size / 2.0

#endregion
