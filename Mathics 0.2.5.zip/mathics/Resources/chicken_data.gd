class_name ChickenData
extends Resource

const CHICKEN_SAVE_PATH: String = "user://chicken_save.tres"

# Status
const MAX_LEVEL: int = 10
const MAX_HUNGER: int = 100
const MAX_HAPPINESS: int = 100

enum COSMETIC {
	HEAD,
	EYE,
	BEAK,
	BODY,
	CLAW,
	COLOR
}

# --- COSMETICS ---
@export var equipped_cosmetics: Dictionary[COSMETIC, String] = {
	COSMETIC.HEAD: "",
	COSMETIC.EYE: "",
	COSMETIC.BODY: "",
	COSMETIC.BEAK: "",
	COSMETIC.CLAW: "",
	COSMETIC.COLOR: "default"
}

#  --- OUTFIT HASH ---
## Returns a unique outfit identifier
func get_outfit_id() -> String:
	return "%s_%s_%s_%s_%s_%s" % [
		equipped_cosmetics[COSMETIC.HEAD],
		equipped_cosmetics[COSMETIC.EYE],
		equipped_cosmetics[COSMETIC.BEAK],
		equipped_cosmetics[COSMETIC.BODY],
		equipped_cosmetics[COSMETIC.CLAW],
		equipped_cosmetics[COSMETIC.COLOR]
	]

# Save data
func save_data() -> void:
	ResourceSaver.save(self,CHICKEN_SAVE_PATH)

# END
