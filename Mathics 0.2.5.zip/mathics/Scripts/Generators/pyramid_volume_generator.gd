class_name PyramidVolumeGenerator
extends RefCounted

## Master generation function accepting difficulty tier
static func generate_question(tier: GM.MASTERY_TIER = GM.MASTERY_TIER.SILVER) -> Dictionary:
	match tier:
		GM.MASTERY_TIER.SILVER:
			return _generate_silver_quiz()
		GM.MASTERY_TIER.GOLD:
			return _generate_gold_quiz()
		GM.MASTERY_TIER.DIAMOND:
			return _generate_diamond_quiz()
		_:
			return _generate_silver_quiz()


# --- 🥈 SILVER TIER (Direct 1-step, all units in cm) ---
static func _generate_silver_quiz() -> Dictionary:
	var use_square_base: bool = randf() > 0.5
	var base_length: float = float(randi_range(3, 8))
	var base_width: float = base_length if use_square_base else float(randi_range(3, 8))
	
	var base_area: float = base_length * base_width
	var height_cm: float = float(_pick_valid_height(int(base_area)))
	var correct_volume: float = (base_area * height_cm) / 3.0
	
	var q_text: String
	if use_square_base:
		q_text = "What is the volume of a square pyramid with base side %d cm and height %d cm?" % [int(base_length), int(height_cm)]
	else:
		q_text = "What is the volume of a rectangular pyramid with base dimensions %d cm × %d cm and height %d cm?" % [int(base_length), int(base_width), int(height_cm)]

	# Distractors:
	# 1. Forgot 1/3 factor (Prism volume: base_area * height)
	var distractor_prism: float = base_area * height_cm
	# 2. Multiplied by 1/2 instead of 1/3
	var distractor_half: float = (base_area * height_cm) / 2.0
	
	return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, correct_volume, [distractor_prism, distractor_half], "cm³")


# --- 🥇 GOLD TIER (Unit conversion: height given in mm) ---
static func _generate_gold_quiz() -> Dictionary:
	var use_square_base: bool = randf() > 0.5
	var base_length: float = float(randi_range(3, 8))
	var base_width: float = base_length if use_square_base else float(randi_range(3, 8))
	
	var base_area: float = base_length * base_width
	var height_cm: float = float(_pick_valid_height(int(base_area)))
	var height_mm: float = height_cm * 10.0
	var correct_volume: float = (base_area * height_cm) / 3.0
	
	var q_text: String
	if use_square_base:
		q_text = "A square pyramid has a base side of %d cm and a vertical height of %d mm. What is its volume?" % [int(base_length), int(height_mm)]
	else:
		q_text = "A rectangular pyramid has a base of %d cm × %d cm and a vertical height of %d mm. What is its volume?" % [int(base_length), int(base_width), int(height_mm)]

	# Distractors:
	# 1. Used raw mm value without converting (10x too large)
	var distractor_raw_mm: float = (base_area * height_mm) / 3.0
	# 2. Forgot 1/3 factor on converted height
	var distractor_prism: float = base_area * height_cm
	
	return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, correct_volume, [distractor_raw_mm, distractor_prism], "cm³")


# --- 💎 DIAMOND TIER (Simple .5 decimals or larger clean values) ---
static func _generate_diamond_quiz() -> Dictionary:
	var is_decimal: bool = randf() > 0.5
	var base_length: float
	var base_width: float
	
	if is_decimal:
		base_length = float(randi_range(2, 6)) + 0.5
		base_width = 2.0 * float(randi_range(1, 4))
	else:
		base_length = float(randi_range(8, 12))
		base_width = float(randi_range(6, 10))
		
	var base_area: float = base_length * base_width
	var height_cm: float = float(_pick_valid_height(int(base_area)))
	var correct_volume: float = (base_area * height_cm) / 3.0
	
	var q_text: String = "Find the volume of a rectangular pyramid with base dimensions %s cm × %s cm and height %s cm." % [
		_format_num(base_length), _format_num(base_width), _format_num(height_cm)
	]

	var distractor_prism: float = base_area * height_cm
	var distractor_offset: float = correct_volume + 12.0
	
	return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, correct_volume, [distractor_prism, distractor_offset], "cm³")


# --- HELPER UTILITIES ---

## Ensures clean integer volume results (divisible by 3)
static func _pick_valid_height(base_area: int) -> int:
	var valid_heights: Array = []
	for h in range(3, 16):
		if (base_area * h) % 3 == 0:
			valid_heights.append(h)
	return valid_heights.pick_random() if valid_heights.size() > 0 else 6

static func _format_num(val: float) -> String:
	if is_equal_approx(val, round(val)):
		return str(int(val))
	return "%.1f" % val

## Builds multiple-choice payload with correct answer and randomized distractor choices
static func _build_quiz_payload(tier: GM.MASTERY_TIER, question: String, correct_val: float, specific_distractors: Array, unit: String) -> Dictionary:
	var correct_str: String = _format_num(correct_val) + " " + unit
	var choices: Array[String] = [correct_str]
	
	# Add specific miscalculation distractors
	for d in specific_distractors:
		var d_str: String = _format_num(d) + " " + unit
		if d > 0 and not choices.has(d_str) and choices.size() < 4:
			choices.append(d_str)
			
	# Fallback distractors if choices count is under 4
	var offsets: Array[float] = [-15.0, 15.0, -30.0, 30.0, 20.0]
	offsets.shuffle()
	
	for offset in offsets:
		if choices.size() >= 4:
			break
		var dummy_val: float = correct_val + offset
		var dummy_str: String = _format_num(dummy_val) + " " + unit
		if dummy_val > 0 and not choices.has(dummy_str):
			choices.append(dummy_str)
			
	choices.shuffle()
	
	return {
		"tier": tier,
		"type": GM.TOPIC.PYRAMID_VOLUME,
		"question_text": question,
		"correct_answer": correct_str,
		"correct_value": correct_val,
		"choices": choices,
		"unit": unit
	}
