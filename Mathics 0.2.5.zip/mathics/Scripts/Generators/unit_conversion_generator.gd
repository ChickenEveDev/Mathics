class_name UnitConversionGenerator
extends RefCounted

# --- 1. MAIN GENERATOR FUNCTION ---
static func generate_question(tier: GM.MASTERY_TIER = GM.MASTERY_TIER.SILVER) -> Dictionary:
	match tier:
		GM.MASTERY_TIER.SILVER:
			return _generate_silver_conversion()
		GM.MASTERY_TIER.GOLD:
			return _generate_gold_conversion()
		GM.MASTERY_TIER.DIAMOND:
			return _generate_diamond_conversion()

	return _generate_silver_conversion()


# --- 2. TIER IMPLEMENTATIONS ---
# SILVER: Direct multiplication using clean integers (m -> cm, kg -> g, L -> mL)
static func _generate_silver_conversion() -> Dictionary:
	var conv_types = [
		{"from": "m", "to": "cm", "factor": 100},
		{"from": "kg", "to": "g", "factor": 1000},
		{"from": "L", "to": "mL", "factor": 1000}
	]
	var cfg = conv_types.pick_random()
	var val = float(randi_range(2, 15))
	var correct = val * cfg["factor"]
	
	var q_text = "Convert %d %s to %s." % [int(val), cfg["from"], cfg["to"]]
	return _build_payload(q_text, correct, cfg["to"], cfg["from"], cfg["factor"], "×")


# GOLD: Clean division (cm -> m, g -> kg, mL -> L) with whole-number answers
static func _generate_gold_conversion() -> Dictionary:
	var conv_types = [
		{"from": "cm", "to": "m", "factor": 100},
		{"from": "g", "to": "kg", "factor": 1000},
		{"from": "mL", "to": "L", "factor": 1000}
	]
	var cfg = conv_types.pick_random()
	var base_answer = randi_range(2, 12)
	var val = float(base_answer * cfg["factor"])
	var correct = float(base_answer)
	
	var q_text = "Convert %d %s to %s." % [int(val), cfg["from"], cfg["to"]]
	return _build_payload(q_text, correct, cfg["to"], cfg["from"], cfg["factor"], "÷")


# DIAMOND: Simple .5 decimal increments or adjacent sub-units (cm -> mm)
static func _generate_diamond_conversion() -> Dictionary:
	var is_decimal = randf() > 0.5
	
	if is_decimal:
		# e.g., 2.5 kg -> 2500 g
		var cfg = [
			{"from": "kg", "to": "g", "factor": 1000},
			{"from": "L", "to": "mL", "factor": 1000},
			{"from": "m", "to": "cm", "factor": 100}
		].pick_random()
		
		var val = float(randi_range(1, 9)) + 0.5
		var correct = val * cfg["factor"]
		var q_text = "Convert %.1f %s to %s." % [val, cfg["from"], cfg["to"]]
		return _build_payload(q_text, correct, cfg["to"], cfg["from"], cfg["factor"], "×")
	else:
		# Adjacent sub-unit conversion (e.g., cm -> mm)
		var val = float(randi_range(5, 40))
		var correct = val * 10.0
		var q_text = "Convert %d cm to mm." % [int(val)]
		return _build_payload(q_text, correct, "mm", "cm", 10, "×")


# --- 3. PAYLOAD & DISTRACTOR BUILDER ---
@warning_ignore("unused_parameter")
static func _build_payload(q_text: String, correct_val: float, to_unit: String, from_unit: String, factor: int, op: String) -> Dictionary:
	var choices: Array[String] = [_format_num(correct_val) + " " + to_unit]
	
	# Common student mistake distractors (wrong operation or off by a power of 10)
	var fake_vals: Array[float] = []
	if op == "×":
		fake_vals.append(correct_val / 10.0)
		fake_vals.append(correct_val * 10.0)
	else:
		fake_vals.append(correct_val * float(factor))
		fake_vals.append(correct_val * 10.0)
		
	for f in fake_vals:
		var formatted_fake = _format_num(f) + " " + to_unit
		if f > 0 and not choices.has(formatted_fake) and choices.size() < 4:
			choices.append(formatted_fake)
			
	# Fallback choices if needed
	while choices.size() < 4:
		var dummy_val = correct_val + [-10.0, 10.0, -100.0, 100.0, 50.0].pick_random()
		var dummy_str = _format_num(dummy_val) + " " + to_unit
		if dummy_val > 0 and not choices.has(dummy_str):
			choices.append(dummy_str)
			
	choices.shuffle()
	
	return {
		"type": GM.TOPIC.UNIT_CONVERSION,
		"question_text": q_text,
		"correct_answer": _format_num(correct_val) + " " + to_unit,
		"choices": choices,
		"target_unit": to_unit
	}

static func _format_num(n: float) -> String:
	if is_equal_approx(n, round(n)):
		return str(int(n))
	return "%.1f" % n









# END
