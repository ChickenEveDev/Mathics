class_name FinancialLiteracyGenerator
extends RefCounted

## Sub-topics within Financial Literacy
enum SubTopic {
	DISCOUNT,       # Percentage discounts and sale prices
	SIMPLE_INTEREST, # I = P * r * t
	COMMISSION,     # Earnings from sales commission
	SALES_TAX       # Tax calculation and total amount due
}

## Main entry point to generate a Financial Literacy question based on difficulty.
static func generate_question(tier: GM.MASTERY_TIER = GM.MASTERY_TIER.SILVER) -> Dictionary:
	match tier:
		GM.MASTERY_TIER.SILVER:
			return _generate_silver_quiz()
		GM.MASTERY_TIER.GOLD:
			return _generate_gold_quiz()
		GM.MASTERY_TIER.DIAMOND:
			return _generate_diamond_quiz()
		_:
			return _generate_silver_quiz()

# TIER GENERATORS

## Tier 1 (Silver): Direct 1-step calculations with friendly base numbers (multiples of 10/100).
static func _generate_silver_quiz() -> Dictionary:
	var sub_topic: SubTopic = [SubTopic.DISCOUNT, SubTopic.SIMPLE_INTEREST, SubTopic.COMMISSION, SubTopic.SALES_TAX].pick_random()
	
	match sub_topic:
		SubTopic.DISCOUNT:
			var original_price: float = float(randi_range(2, 10) * 100) # ₱200 - ₱1000
			var discount_rate: float = [10.0, 20.0, 25.0, 50.0].pick_random()
			var discount_amt: float = (original_price * discount_rate) / 100.0
			var correct_val: float = original_price - discount_amt
			
			var q_text: String = "A bag costs ₱%d. It is on sale at a %d%% discount. What is the sale price?" % [int(original_price), int(discount_rate)]
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, correct_val, [discount_amt, original_price + discount_amt], "₱")

		SubTopic.SIMPLE_INTEREST:
			var principal: float = float(randi_range(1, 5) * 1000) # ₱1,000 - ₱5,000
			var rate: float = [5.0, 10.0].pick_random()
			var time_years: float = float(randi_range(1, 3))
			var interest: float = principal * (rate / 100.0) * time_years
			
			var q_text: String = "Calculate the simple interest earned on ₱%d at an annual rate of %d%% for %d year(s)." % [int(principal), int(rate), int(time_years)]
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, interest, [principal + interest, (principal * rate) / 100.0], "₱")

		SubTopic.COMMISSION:
			var total_sales: float = float(randi_range(2, 8) * 1000) # ₱2,000 - ₱8,000
			var comm_rate: float = [5.0, 10.0].pick_random()
			var commission: float = (total_sales * comm_rate) / 100.0
			
			var q_text: String = "An agent earns a %d%% commission on sales. If total sales were ₱%d, how much commission did they make?" % [int(comm_rate), int(total_sales)]
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, commission, [total_sales - commission, comm_rate * 100.0], "₱")

		SubTopic.SALES_TAX:
			var item_price: float = float(randi_range(1, 10) * 100) # ₱100 - ₱1000
			var tax_rate: float = [5.0, 10.0, 12.0].pick_random()
			var tax_amount: float = (item_price * tax_rate) / 100.0
			
			var q_text: String = "A pair of shoes costs ₱%d. How much sales tax is added if the sales tax rate is %d%%?" % [int(item_price), int(tax_rate)]
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, tax_amount, [item_price + tax_amount, item_price - tax_amount], "₱")

	return {}


## Tier 2 (Gold): Real-world contexts with intermediate percentage multipliers.
static func _generate_gold_quiz() -> Dictionary:
	var sub_topic: SubTopic = [SubTopic.DISCOUNT, SubTopic.SIMPLE_INTEREST, SubTopic.COMMISSION, SubTopic.SALES_TAX].pick_random()

	match sub_topic:
		SubTopic.DISCOUNT:
			var original_price: float = float(randi_range(12, 35) * 20) # ₱240 - ₱700
			var discount_rate: float = [15.0, 30.0, 35.0, 40.0].pick_random()
			var discount_amt: float = (original_price * discount_rate) / 100.0
			var correct_val: float = original_price - discount_amt
			
			var q_text: String = "A jacket costs ₱%d. After applying a %d%% promotional discount, what is the final price?" % [int(original_price), int(discount_rate)]
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, correct_val, [discount_amt, original_price + discount_amt], "₱")

		SubTopic.SIMPLE_INTEREST:
			var principal: float = float(randi_range(6, 20) * 500) # ₱3,000 - ₱10,000
			var rate: float = [4.0, 6.0, 8.0, 12.0].pick_random()
			var time_years: float = float(randi_range(2, 5))
			var interest: float = principal * (rate / 100.0) * time_years
			
			var q_text: String = "Find the simple interest on a ₱%d loan at %d%% interest per year after %d years." % [int(principal), int(rate), int(time_years)]
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, interest, [principal + interest, interest / time_years], "₱")

		SubTopic.COMMISSION:
			var total_sales: float = float(randi_range(15, 50) * 1000) # ₱15,000 - ₱50,000
			var comm_rate: float = [3.0, 6.0, 8.0, 15.0].pick_random()
			var commission: float = (total_sales * comm_rate) / 100.0
			
			var q_text: String = "A seller sold a gadget set worth ₱%d with a %d%% commission rate. What is their earnings?" % [int(total_sales), int(comm_rate)]
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, commission, [total_sales - commission, commission * 2.0], "₱")

		SubTopic.SALES_TAX:
			var price: float = float(randi_range(5, 30) * 50) # ₱250 - ₱1500
			var tax_rate: float = [8.0, 12.0, 15.0].pick_random()
			var total_cost: float = price * (1.0 + (tax_rate / 100.0))
			
			var q_text: String = "An item costs ₱%d before tax. If the sales tax rate is %d%%, what is the total cost including tax?" % [int(price), int(tax_rate)]
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, total_cost, [(price * tax_rate) / 100.0, price - ((price * tax_rate) / 100.0)], "₱")

	return {}


## Tier 3 (Diamond): Multi-step calculations or reverse percentage/financial problems.
static func _generate_diamond_quiz() -> Dictionary:
	var sub_topic: SubTopic = [SubTopic.DISCOUNT, SubTopic.SIMPLE_INTEREST, SubTopic.COMMISSION, SubTopic.SALES_TAX].pick_random()

	match sub_topic:
		SubTopic.DISCOUNT: # Reverse calculation: Find Original Price given Sale Price & Discount
			var original_price: float = float(randi_range(4, 15) * 100) # ₱400 - ₱1,500
			var discount_rate: float = [20.0, 25.0, 50.0].pick_random()
			var sale_price: float = original_price * (1.0 - (discount_rate / 100.0))
			
			var q_text: String = "After receiving a %d%% discount, a student paid ₱%d for a textbook. What was its original price?" % [int(discount_rate), int(sale_price)]
			# Distractor 1: Forward calculation on sale price instead of reverse
			var distractor_forward: float = sale_price * (1.0 + (discount_rate / 100.0))
			return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, original_price, [distractor_forward, sale_price - discount_rate], "₱")

		SubTopic.SIMPLE_INTEREST: # Multi-step: Total Amount Repaid (Principal + Interest)
			var principal: float = float(randi_range(2, 10) * 1000) # ₱2,000 - ₱10,000
			var rate: float = [5.0, 8.0, 10.0].pick_random()
			var time_years: float = float(randi_range(2, 4))
			var interest: float = principal * (rate / 100.0) * time_years
			var total_payback: float = principal + interest
			
			var q_text: String = "A borrower took a ₱%d loan at %d%% annual simple interest. What is the TOTAL amount to be repaid after %d years?" % [int(principal), int(rate), int(time_years)]
			return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, total_payback, [interest, principal - interest], "₱")

		SubTopic.COMMISSION: # Multi-step: Base Salary + Commission Earnings
			var base_salary: float = float(randi_range(5, 12) * 1000) # ₱5,000 - ₱12,000
			var sales: float = float(randi_range(1, 4) * 10000)      # ₱10,000 - ₱40,000
			var comm_rate: float = [5.0, 10.0].pick_random()
			var commission: float = (sales * comm_rate) / 100.0
			var total_earnings: float = base_salary + commission
			
			var q_text: String = "A sales rep has a base salary of ₱%d plus a %d%% commission on sales. If they make ₱%d in sales, what is their total income?" % [int(base_salary), int(comm_rate), int(sales)]
			return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, total_earnings, [commission, base_salary, sales + commission], "₱")

		SubTopic.SALES_TAX:
			var original_price: float = float(randi_range(2, 10) * 200)
			var tax_rate: float = 10.0
			var total_with_tax: float = original_price * (1.0 + (tax_rate / 100.0))
			
			var q_text: String = "The total price of a TV including %d%% sales tax is ₱%d. What was the price before tax?" % [int(tax_rate), int(total_with_tax)]
			var distractor_wrong_perc: float = total_with_tax * (1.0 - (tax_rate / 100.0))
			return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, original_price, [distractor_wrong_perc, total_with_tax - tax_rate], "₱")

	return {}

# HELPER FUNCTIONS

## Formats float values into whole numbers or clean 2-decimal currency strings.
static func _format_num(val: float, unit: String) -> String:
	if is_equal_approx(val, round(val)):
		return "%s%d" % [unit, int(val)]
	return "%s%.2f" % [unit, val]


## Builds the standardized question payload dictionary.
static func _build_quiz_payload(tier: GM.MASTERY_TIER, question: String, correct_val: float, specific_distractors: Array, unit: String) -> Dictionary:
	var correct_str: String = _format_num(correct_val, unit)
	var choices: Array[String] = [correct_str]
	
	# Add specific miscalculation distractors
	for d in specific_distractors:
		var d_str: String = _format_num(d, unit)
		if d > 0 and not choices.has(d_str) and choices.size() < 4:
			choices.append(d_str)
			
	# Fill remaining choices up to 4 using safe monetary offsets
	var offsets: Array[float] = [-50.0, 50.0, -100.0, 100.0, -20.0, 20.0, -200.0, 200.0]
	offsets.shuffle()
	
	for offset in offsets:
		if choices.size() >= 4:
			break
		var dummy_val: float = correct_val + offset
		var dummy_str: String = _format_num(dummy_val, unit)
		if dummy_val > 0 and not choices.has(dummy_str):
			choices.append(dummy_str)
			
	choices.shuffle()
	
	return {
		"tier": tier,
		"type": GM.TOPIC.FINANCIAL_LITERACY,
		"question_text": question,
		"correct_answer": correct_str,
		"correct_value": correct_val,
		"choices": choices,
		"unit": unit
	}
