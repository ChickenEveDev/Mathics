class_name PercentileChangesGenerator
extends RefCounted

## Main entry point to generate a multiple-choice percentage change question.
static func generate_question(tier: GM.MASTERY_TIER = GM.MASTERY_TIER.SILVER) -> Dictionary:
	match tier:
		GM.MASTERY_TIER.SILVER:
			return _generate_silver_quiz()
		GM.MASTERY_TIER.GOLD:
			return _generate_gold_quiz()
		GM.MASTERY_TIER.DIAMOND:
			return _generate_diamond_quiz()
		_:
			return _generate_silver_quiz()


## Generates Silver Tier questions (Direct 1-step percentage increase/decrease with clean numbers).
static func _generate_silver_quiz() -> Dictionary:
	var is_increase: bool = randf() > 0.5
	var original_amount: float = float(randi_range(2, 10) * 10) # 20, 30, ..., 100
	var percent_change: float = [10.0, 20.0, 25.0, 50.0].pick_random()
	
	var change_amount: float = (original_amount * percent_change) / 100.0
	var correct_val: float = original_amount + change_amount if is_increase else original_amount - change_amount
	
	var q_text: String
	if is_increase:
		q_text = "A shirt originally costs ₱%d. Its price increases by %d%%. What is the new price?" % [int(original_amount), int(percent_change)]
	else:
		q_text = "A book originally costs ₱%d. It is on sale at a %d%% discount. What is the sale price?" % [int(original_amount), int(percent_change)]

	# Common Misconceptions / Distractors:
	# 1. Added or subtracted raw percentage rate instead of percentage value (e.g., 100 - 20 = 80)
	var distractor_raw_op: float = original_amount + percent_change if is_increase else original_amount - percent_change
	# 2. Calculated the change amount only, forgetting to add/subtract from original
	var distractor_change_only: float = change_amount
	# 3. Applied wrong direction (decreased instead of increased or vice versa)
	var distractor_wrong_direction: float = original_amount - change_amount if is_increase else original_amount + change_amount

	return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, correct_val, [distractor_raw_op, distractor_change_only, distractor_wrong_direction], "₱")


## Generates Gold Tier questions (Real-world retail contexts with 15%, 35%, 75% multipliers).
static func _generate_gold_quiz() -> Dictionary:
	var is_increase: bool = randf() > 0.5
	var original_amount: float = float(randi_range(12, 40) * 5) # 60, 65, 70... 200
	var percent_change: float = [15.0, 35.0, 40.0, 75.0].pick_random()
	
	var change_amount: float = (original_amount * percent_change) / 100.0
	var correct_val: float = original_amount + change_amount if is_increase else original_amount - change_amount
	
	var q_text: String
	if is_increase:
		q_text = "The price of a grocery batch was ₱%d. Due to inflation, it increased by %d%%. What is the updated price?" % [int(original_amount), int(percent_change)]
	else:
		q_text = "A pair of shoes originally costing ₱%d is marked down by %d%%. What is the final price?" % [int(original_amount), int(percent_change)]

	# Common Misconceptions / Distractors:
	# 1. Returned change amount only
	var distractor_change_only: float = change_amount
	# 2. Subtracted discount percentage from 100% incorrectly (off-by-5 error)
	var distractor_off_target: float = original_amount - ((original_amount * (percent_change - 5.0)) / 100.0)

	return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, correct_val, [distractor_change_only, distractor_off_target], "₱")


## Generates Diamond Tier questions (Finding original value given the percentage change and final amount).
static func _generate_diamond_quiz() -> Dictionary:
	var is_increase: bool = randf() > 0.5
	var original_amount: float = float(randi_range(4, 15) * 50) # 200, 250, ..., 750
	var percent_change: float = [10.0, 20.0, 25.0, 50.0].pick_random()
	
	var final_amount: float = original_amount * (1.0 + (percent_change / 100.0)) if is_increase else original_amount * (1.0 - (percent_change / 100.0))
	var correct_val: float = original_amount
	
	var q_text: String
	if is_increase:
		q_text = "After a %d%% price increase, an item now costs ₱%d. What was its original price?" % [int(percent_change), int(final_amount)]
	else:
		q_text = "After receiving a %d%% discount, a student paid ₱%d for a bag. What was the original price?" % [int(percent_change), int(final_amount)]

	# Common Misconceptions / Distractors:
	# 1. Calculated percentage of the FINAL price instead of solving backwards: final * (1 +/- rate)
	var distractor_forward_calc: float = final_amount * (1.0 - (percent_change / 100.0)) if is_increase else final_amount * (1.0 + (percent_change / 100.0))
	# 2. Subtracting/Adding raw percentage from final price
	var distractor_raw_sub: float = final_amount - percent_change

	return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, correct_val, [distractor_forward_calc, distractor_raw_sub], "₱")


## Formats float values as clean whole numbers or formatted currency strings.
static func _format_num(val: float, unit: String) -> String:
	if is_equal_approx(val, round(val)):
		return "%s%d" % [unit, int(val)]
	return "%s%.2f" % [unit, val]


## Builds the quiz payload dictionary containing formatted choices for UI rendering.
static func _build_quiz_payload(tier: GM.MASTERY_TIER, question: String, correct_val: float, specific_distractors: Array, unit: String) -> Dictionary:
	var correct_str: String = _format_num(correct_val, unit)
	var choices: Array[String] = [correct_str]
	
	# Add specific miscalculation distractors
	for d in specific_distractors:
		var d_str: String = _format_num(d, unit)
		if d > 0 and not choices.has(d_str) and choices.size() < 4:
			choices.append(d_str)
			
	# Fill remaining choices up to 4 using safe numerical offsets
	var offsets: Array[float] = [-20.0, 20.0, -50.0, 50.0, -10.0, 10.0]
	offsets.shuffle()
	
	for offset in offsets:
		if choices.size() >= 4:
			break
		var dummy_val: float = correct_val + offset
		var dummy_str: String = _format_num(dummy_val, unit)
		if dummy_val > 0 and not choices.has(dummy_str):
			choices.append(dummy_str)
			
	choices.shuffle()
	
	return {
		"tier": tier,
		"type": GM.TOPIC.PERCENTILE_CHANGES,
		"question_text": question,
		"correct_answer": correct_str,
		"correct_value": correct_val,
		"choices": choices,
		"unit": unit
	}
