class_name PolygonPropertiesGenerator
extends RefCounted

## Polygon sides and names lookup dictionary
const POLYGONS: Dictionary = {
	3: "triangle",
	4: "quadrilateral",
	5: "pentagon",
	6: "hexagon",
	7: "heptagon",
	8: "octagon",
	9: "nonagon",
	10: "decagon",
	12: "dodecagon"
}

## Main entry point to generate a Polygon Properties question based on difficulty tier.
static func generate_question(tier: GM.MASTERY_TIER = GM.MASTERY_TIER.SILVER) -> Dictionary:
	match tier:
		GM.MASTERY_TIER.SILVER:
			return _generate_silver_quiz()
		GM.MASTERY_TIER.GOLD:
			return _generate_gold_quiz()
		GM.MASTERY_TIER.DIAMOND:
			return _generate_diamond_quiz()
		_:
			return _generate_silver_quiz()


# TIER GENERATORS

# Tier 1 (Silver): Direct identification of sides, sum of interior angles, or exterior angle sum.
static func _generate_silver_quiz() -> Dictionary:
	var mode: int = randi_range(0, 2)
	var sides: int = [3, 4, 5, 6, 8, 10].pick_random()
	var p_name: String = POLYGONS[sides]
	
	match mode:
		0: # Number of sides in a polygon
			var q_text: String = "How many sides does a regular %s have?" % p_name
			var distractors: Array = [sides - 1, sides + 1, sides + 2]
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, float(sides), distractors, " sides")

		1: # Sum of interior angles S = (n - 2) * 180
			var sum_interior: float = float((sides - 2) * 180)
			var q_text: String = "What is the sum of the interior angles of a %s?" % p_name
			var distractor_n180: float = float(sides * 180)
			var distractor_wrong_n: float = float((sides - 1) * 180)
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, sum_interior, [distractor_n180, distractor_wrong_n], "°")

		2: # Sum of exterior angles (Always 360°)
			var q_text: String = "What is the sum of the exterior angles of a regular %s?" % p_name
			var distractor_interior: float = float((sides - 2) * 180)
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, 360.0, [180.0, distractor_interior, 540.0], "°")

	return {}


# Tier 2 (Gold): Single interior/exterior angle of a regular polygon or finding diagonals count.
static func _generate_gold_quiz() -> Dictionary:
	var mode: int = randi_range(0, 2)
	var sides: int = [5, 6, 8, 9, 10, 12].pick_random()
	var p_name: String = POLYGONS[sides]

	match mode:
		0: # Measure of ONE interior angle of a regular polygon
			var sum_interior: float = float((sides - 2) * 180)
			var single_interior: float = sum_interior / float(sides)
			
			var q_text: String = "What is the measure of ONE interior angle of a regular %s?" % p_name
			var distractor_ext: float = 360.0 / float(sides)
			var distractor_sum: float = sum_interior
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, single_interior, [distractor_ext, distractor_sum], "°")

		1: # Measure of ONE exterior angle of a regular polygon
			var single_exterior: float = 360.0 / float(sides)
			
			var q_text: String = "What is the measure of ONE exterior angle of a regular %s?" % p_name
			var single_interior: float = 180.0 - single_exterior
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, single_exterior, [single_interior, 360.0], "°")

		2: # Number of diagonals d = n * (n - 3) / 2
			@warning_ignore("integer_division")
			var diagonals: float = float((sides * (sides - 3)) / 2)
			
			var q_text: String = "How many diagonals can be drawn in a convex %s?" % p_name
			var distractor_no_div: float = float(sides * (sides - 3))
			@warning_ignore("integer_division")
			var distractor_wrong_formula: float = float((sides * (sides - 1)) / 2)
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, diagonals, [distractor_no_div, distractor_wrong_formula], " diagonals")

	return {}


# Tier 3 (Diamond): Reverse calculations (finding sides from angle sums) or finding missing interior angles.
static func _generate_diamond_quiz() -> Dictionary:
	var mode: int = randi_range(0, 1)

	match mode:
		0: # Find the number of sides given the sum of interior angles
			var sides: int = [5, 6, 7, 8, 10, 12].pick_random()
			var sum_interior: int = (sides - 2) * 180
			
			var q_text: String = "A convex polygon has an interior angle sum of %d°. How many sides does it have?" % sum_interior
			var distractor_sub: float = float(sides - 2)
			var distractor_add: float = float(sides + 2)
			return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, float(sides), [distractor_sub, distractor_add], " sides")

		1: # Find number of sides given one interior angle of a regular polygon
			var sides: int = [5, 6, 8, 10, 12].pick_random()
			var single_interior: float = float((sides - 2) * 180) / float(sides)
			
			var q_text: String = "Each interior angle of a regular polygon measures %s°. How many sides does the polygon have?" % _format_clean(single_interior)
			var distractor_ext_sides: float = 360.0 / single_interior if single_interior > 0 else float(sides + 1)
			return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, float(sides), [distractor_ext_sides, float(sides - 1)], " sides")

	return {}


# HELPER FUNCTIONS

# Cleans up floating numbers for display strings
static func _format_clean(val: float) -> String:
	if is_equal_approx(val, round(val)):
		return "%d" % int(val)
	return "%.1f" % val


# Formats numerical output with unit labels
static func _format_num(val: float, unit: String) -> String:
	if is_equal_approx(val, round(val)):
		return "%d%s" % [int(val), unit]
	return "%.1f%s" % [val, unit]


# Builds standardized question payload dictionary
static func _build_quiz_payload(tier: GM.MASTERY_TIER, question: String, correct_val: float, specific_distractors: Array, unit: String) -> Dictionary:
	var correct_str: String = _format_num(correct_val, unit)
	var choices: Array[String] = [correct_str]
	
	# Add specific miscalculation distractors
	for d in specific_distractors:
		var d_str: String = _format_num(d, unit)
		if d > 0 and not choices.has(d_str) and choices.size() < 4:
			choices.append(d_str)
			
	# Fill remaining choices up to 4 using safe numerical offsets
	var offsets: Array[float] = [-10.0, 10.0, -20.0, 20.0, -5.0, 5.0, -2.0, 2.0]
	offsets.shuffle()
	
	for offset in offsets:
		if choices.size() >= 4:
			break
		var dummy_val: float = correct_val + offset
		var dummy_str: String = _format_num(dummy_val, unit)
		if dummy_val > 0 and not choices.has(dummy_str):
			choices.append(dummy_str)
			
	choices.shuffle()
	
	return {
		"tier": tier,
		"type": GM.TOPIC.POLYGON_PROPERTIES,
		"question_text": question,
		"correct_answer": correct_str,
		"correct_value": correct_val,
		"choices": choices,
		"unit": unit
	}
