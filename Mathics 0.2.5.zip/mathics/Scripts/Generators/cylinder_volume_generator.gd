class_name CylinderVolumeGenerator
extends RefCounted

## Standard pi approximation for Grade 7 geometry calculations.
const PI_APPROX: float = 3.14

## Main entry point to generate a multiple-choice cylinder volume question.
static func generate_question(tier: GM.MASTERY_TIER = GM.MASTERY_TIER.SILVER) -> Dictionary:
	match tier:
		GM.MASTERY_TIER.SILVER:
			return _generate_silver_quiz()
		GM.MASTERY_TIER.GOLD:
			return _generate_gold_quiz()
		GM.MASTERY_TIER.DIAMOND:
			return _generate_diamond_quiz()
		_:
			return _generate_silver_quiz()


## Generates Silver Tier questions (Direct 1-step, whole numbers, radius given in cm).
static func _generate_silver_quiz() -> Dictionary:
	var radius: float = float(randi_range(2, 6))
	var height: float = float(randi_range(4, 10))
	
	# Formula: V = pi * r^2 * h
	var correct_vol: float = snapped(PI_APPROX * (radius * radius) * height, 0.1)
	var q_text: String = "What is the volume of a cylinder with a base radius of %d cm and a height of %d cm? (Use PI ≈ 3.14)" % [int(radius), int(height)]

	# Common Misconceptions / Distractors:
	# 1. Forgot to square radius: pi * r * h
	var distractor_no_square: float = snapped(PI_APPROX * radius * height, 0.1)
	# 2. Used diameter formula mistake: pi * (r * 2)^2 * h
	var distractor_diameter_used: float = snapped(PI_APPROX * (radius * 2.0) * (radius * 2.0) * height, 0.1)
	
	return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, correct_vol, [distractor_no_square, distractor_diameter_used], "cm³")


## Generates Gold Tier questions (Diameter given instead of radius OR height in mm).
static func _generate_gold_quiz() -> Dictionary:
	var is_diameter_trap: bool = randf() > 0.5
	var radius: float = float(randi_range(3, 7))
	var height_cm: float = float(randi_range(5, 12))
	
	var correct_vol: float = snapped(PI_APPROX * (radius * radius) * height_cm, 0.1)
	var q_text: String = ""
	var specific_distractors: Array = []
	
	if is_diameter_trap:
		var diameter: float = radius * 2.0
		q_text = "Find the volume of a cylinder with a base diameter of %d cm and a height of %d cm. (Use PI ≈ 3.14)" % [int(diameter), int(height_cm)]
		
		# Distractor: Used raw diameter directly as radius -> pi * d^2 * h
		var distractor_raw_diameter: float = snapped(PI_APPROX * (diameter * diameter) * height_cm, 0.1)
		# Distractor: Forgot to square radius -> pi * r * h
		var distractor_no_square: float = snapped(PI_APPROX * radius * height_cm, 0.1)
		specific_distractors = [distractor_raw_diameter, distractor_no_square]
	else:
		# Height given in mm requiring conversion to cm
		var height_mm: float = height_cm * 10.0
		q_text = "A cylinder has a base radius of %d cm and a height of %d mm. What is its volume in cm³? (Use PI ≈ 3.14)" % [int(radius), int(height_mm)]
		
		# Distractor: Plugged raw mm value without converting -> pi * r^2 * height_mm
		var distractor_raw_mm: float = snapped(PI_APPROX * (radius * radius) * height_mm, 0.1)
		var distractor_no_square: float = snapped(PI_APPROX * radius * height_cm, 0.1)
		specific_distractors = [distractor_raw_mm, distractor_no_square]

	return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, correct_vol, specific_distractors, "cm³")


## Generates Diamond Tier questions (Simple .5 decimals or larger dimensions).
static func _generate_diamond_quiz() -> Dictionary:
	var is_decimal: bool = randf() > 0.5
	var radius: float
	var height_cm: float
	
	if is_decimal:
		# Gentle .5 decimal radius (e.g., 2.5 cm, 3.5 cm)
		radius = float(randi_range(2, 5)) + 0.5
		height_cm = float(randi_range(4, 8))
	else:
		# Slightly larger whole integers
		radius = float(randi_range(7, 10))
		height_cm = float(randi_range(10, 15))
		
	var correct_vol: float = snapped(PI_APPROX * (radius * radius) * height_cm, 0.1)
	
	var q_text: String = "Calculate the volume of a cylinder with a radius of %s cm and a height of %s cm. (Use PI ≈ 3.14)" % [
		_format_num(radius), _format_num(height_cm)
	]

	# Distractor: Forgot to square radius -> pi * r * h
	var distractor_no_square: float = snapped(PI_APPROX * radius * height_cm, 0.1)
	# Distractor: Applied 1/3 factor (confused cylinder formula with cone/pyramid)
	var distractor_cone_trap: float = snapped((PI_APPROX * (radius * radius) * height_cm) / 3.0, 0.1)
	
	return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, correct_vol, [distractor_no_square, distractor_cone_trap], "cm³")


## Formats float values without trailing zeroes when whole numbers.
static func _format_num(val: float) -> String:
	if is_equal_approx(val, round(val)):
		return str(int(val))
	return "%.1f" % val


## Builds the quiz payload dictionary containing formatted multiple choice options.
static func _build_quiz_payload(tier: GM.MASTERY_TIER, question: String, correct_val: float, specific_distractors: Array, unit: String) -> Dictionary:
	var correct_str: String = _format_num(correct_val) + " " + unit
	var choices: Array[String] = [correct_str]
	
	# Add specific miscalculation distractors
	for d in specific_distractors:
		var d_str: String = _format_num(d) + " " + unit
		if d > 0 and not choices.has(d_str) and choices.size() < 4:
			choices.append(d_str)
			
	# Fill remaining choices up to 4 using safe numerical offsets
	var offsets: Array[float] = [-15.0, 15.0, -25.0, 25.0, 40.0]
	offsets.shuffle()
	
	for offset in offsets:
		if choices.size() >= 4:
			break
		var dummy_val: float = snapped(correct_val + offset, 0.1)
		var dummy_str: String = _format_num(dummy_val) + " " + unit
		if dummy_val > 0 and not choices.has(dummy_str):
			choices.append(dummy_str)
			
	choices.shuffle()
	
	return {
		"tier": tier,
		"type": GM.TOPIC.CYLINDER_VOLUME,
		"question_text": question,
		"correct_answer": correct_str,
		"correct_value": correct_val,
		"choices": choices,
		"unit": unit
	}
