class_name SpeedRateGenerator
extends RefCounted

## Main entry point to generate a Speed, Distance, and Time question based on mastery tier.
static func generate_question(tier: GM.MASTERY_TIER = GM.MASTERY_TIER.SILVER) -> Dictionary:
	match tier:
		GM.MASTERY_TIER.SILVER:
			return _generate_silver_quiz()
		GM.MASTERY_TIER.GOLD:
			return _generate_gold_quiz()
		GM.MASTERY_TIER.DIAMOND:
			return _generate_diamond_quiz()
		_:
			return _generate_silver_quiz()


# TIER GENERATORS

# Tier 1 (Silver): Direct 1-step calculations (S = D/T, D = S*T, T = D/S) with whole numbers.
static func _generate_silver_quiz() -> Dictionary:
	var mode: int = randi_range(0, 2)
	
	match mode:
		0: # Find Speed (S = D / T)
			var time_hrs: float = float(randi_range(2, 5))
			var speed_kmh: float = float(randi_range(3, 10) * 10) # 30, 40, ..., 100 km/h
			var distance_km: float = speed_kmh * time_hrs
			
			var q_text: String = "A car travels %d km in %d hours. What is its average speed?" % [int(distance_km), int(time_hrs)]
			var distractor_mult: float = distance_km * time_hrs
			var distractor_sub: float = distance_km - time_hrs
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, speed_kmh, [distractor_mult, distractor_sub], " km/h")

		1: # Find Distance (D = S * T)
			var speed_kmh: float = float(randi_range(4, 9) * 10) # 40 to 90 km/h
			var time_hrs: float = float(randi_range(2, 6))
			var distance_km: float = speed_kmh * time_hrs
			
			var q_text: String = "A bus travels at a speed of %d km/h for %d hours. How far does it travel?" % [int(speed_kmh), int(time_hrs)]
			var distractor_div: float = speed_kmh / time_hrs
			var distractor_add: float = speed_kmh + time_hrs
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, distance_km, [distractor_div, distractor_add], " km")

		2: # Find Time (T = D / S)
			var time_hrs: float = float(randi_range(2, 8))
			var speed_kmh: float = float(randi_range(4, 10) * 10)
			var distance_km: float = speed_kmh * time_hrs
			
			var q_text: String = "How many hours will it take a train traveling at %d km/h to cover a distance of %d km?" % [int(speed_kmh), int(distance_km)]
			var distractor_mult: float = distance_km * speed_kmh
			var distractor_sub: float = distance_km - speed_kmh
			return _build_quiz_payload(GM.MASTERY_TIER.SILVER, q_text, time_hrs, [distractor_mult, distractor_sub], " hours")

	return {}


# Tier 2 (Gold): Fractional hours (e.g. 1.5 hrs, 2.5 hrs, 30 mins) or unit conversions (m/s to km/h).
static func _generate_gold_quiz() -> Dictionary:
	var mode: int = randi_range(0, 2)

	match mode:
		0: # Decimal time values (e.g., 2.5 hours)
			var time_hrs: float = float(randi_range(3, 9)) * 0.5 # 1.5, 2.0, 2.5, 3.0...
			var speed_kmh: float = float(randi_range(6, 12) * 10)
			var distance_km: float = speed_kmh * time_hrs
			
			var q_text: String = "A motorcycle covers %s km in %.1f hours. What is its speed?" % [_format_clean(distance_km), time_hrs]
			var distractor_wrong_time: float = distance_km / (time_hrs + 0.5)
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, speed_kmh, [distractor_wrong_time], " km/h")

		1: # Time given in minutes (e.g., 30 mins, 45 mins)
			var minutes: float = [15.0, 30.0, 45.0].pick_random()
			var time_hrs: float = minutes / 60.0
			var speed_kmh: float = float(randi_range(4, 10) * 12) # Guarantees clean distances
			var distance_km: float = speed_kmh * time_hrs
			
			var q_text: String = "A cyclist travels at %d km/h for %d minutes. How far do they travel?" % [int(speed_kmh), int(minutes)]
			var distractor_direct_mult: float = speed_kmh * minutes # Forgot to convert minutes to hours
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, distance_km, [distractor_direct_mult], " km")

		2: # Average speed over 2 legs of a journey
			var leg1_dist: float = float(randi_range(2, 5) * 20)
			var leg1_time: float = float(randi_range(1, 3))
			var leg2_dist: float = float(randi_range(2, 5) * 20)
			var leg2_time: float = float(randi_range(1, 3))
			
			var total_dist: float = leg1_dist + leg2_dist
			var total_time: float = leg1_time + leg2_time
			var avg_speed: float = total_dist / total_time
			
			var q_text: String = "A truck travels %d km in %d hours, then another %d km in %d hours. What is its overall average speed?" % [int(leg1_dist), int(leg1_time), int(leg2_dist), int(leg2_time)]
			var distractor_avg_speeds: float = ((leg1_dist / leg1_time) + (leg2_dist / leg2_time)) / 2.0
			return _build_quiz_payload(GM.MASTERY_TIER.GOLD, q_text, avg_speed, [distractor_avg_speeds], " km/h")

	return {}


# Tier 3 (Diamond): Multi-step meeting/chase problems, reverse calculations, or rate adjustments.
static func _generate_diamond_quiz() -> Dictionary:
	var mode: int = randi_range(0, 1)

	match mode:
		0: # Two objects moving towards each other (Relative Speed)
			var speed_a: float = float(randi_range(4, 8) * 10) # 40 - 80 km/h
			var speed_b: float = float(randi_range(5, 9) * 10) # 50 - 90 km/h
			var time_hrs: float = float(randi_range(2, 4))
			var total_distance: float = (speed_a + speed_b) * time_hrs
			
			var q_text: String = "Two cars start %d km apart and drive towards each other at %d km/h and %d km/h. How many hours until they meet?" % [int(total_distance), int(speed_a), int(speed_b)]
			var distractor_sub_speed: float = total_distance / abs(speed_a - speed_b) if speed_a != speed_b else time_hrs + 2.0
			return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, time_hrs, [distractor_sub_speed], " hours")

		1: # Speed increase / Time saved comparison
			var orig_speed: float = 60.0
			var orig_time: float = float(randi_range(3, 6))
			var distance: float = orig_speed * orig_time
			var new_speed: float = 90.0
			var new_time: float = distance / new_speed
			var time_saved: float = orig_time - new_time
			
			var q_text: String = "A delivery driver takes %d hours to cover a trip at 60 km/h. If they increase speed to 90 km/h, how many hours do they save?" % [int(orig_time)]
			return _build_quiz_payload(GM.MASTERY_TIER.DIAMOND, q_text, time_saved, [new_time, orig_time + new_time], " hours")

	return {}


# HELPER FUNCTIONS

# Cleans up floating numbers for display strings
static func _format_clean(val: float) -> String:
	if is_equal_approx(val, round(val)):
		return "%d" % int(val)
	return "%.1f" % val


# Formats numerical output with unit labels
static func _format_num(val: float, unit: String) -> String:
	if is_equal_approx(val, round(val)):
		return "%d%s" % [int(val), unit]
	return "%.2f%s" % [val, unit]


# Builds standardized question payload dictionary
static func _build_quiz_payload(tier: GM.MASTERY_TIER, question: String, correct_val: float, specific_distractors: Array, unit: String) -> Dictionary:
	var correct_str: String = _format_num(correct_val, unit)
	var choices: Array[String] = [correct_str]
	
	# Add specific miscalculation distractors
	for d in specific_distractors:
		var d_str: String = _format_num(d, unit)
		if d > 0 and not choices.has(d_str) and choices.size() < 4:
			choices.append(d_str)
			
	# Fill remaining choices up to 4 using safe numerical offsets
	var offsets: Array[float] = [-10.0, 10.0, -20.0, 20.0, -5.0, 5.0, -15.0, 15.0]
	offsets.shuffle()
	
	for offset in offsets:
		if choices.size() >= 4:
			break
		var dummy_val: float = correct_val + offset
		var dummy_str: String = _format_num(dummy_val, unit)
		if dummy_val > 0 and not choices.has(dummy_str):
			choices.append(dummy_str)
			
	choices.shuffle()
	
	return {
		"tier": tier,
		"type": GM.TOPIC.SPEED_RATE,
		"question_text": question,
		"correct_answer": correct_str,
		"correct_value": correct_val,
		"choices": choices,
		"unit": unit
	}
