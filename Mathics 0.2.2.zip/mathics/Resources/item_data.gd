class_name ItemData
extends Resource

enum CATEGORY {
	FOOD,
	HEAD,
	EYE,
	BEAK,
	BODY,
	CLAW,
	COLOR
}

@export var id: String = ""
@export var name: String = ""
@export var category: CATEGORY = CATEGORY.FOOD
@export var icon: Texture2D
@export var price_gold: int = 0
@export var price_diamond: int = 0
@export var stat_value: float = 0.0
