class_name ConceptQuestion
extends Resource

enum CATEGORY {
	ANGLES,
	TRIANGLES,
	POLYNOMIALS,
	STATISTICS,
	NUMBER_SYSTEMS
}

@export var category: CATEGORY
@export_multiline() var question: String = ""
@export_multiline() var answer: String = ""

# END
