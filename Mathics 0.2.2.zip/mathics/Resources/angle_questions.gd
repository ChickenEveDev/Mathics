class_name AngleQuestions
extends Resource

@export var angle: float = 0.0
