extends Node

#region Constants
# Save paths
const CHICKEN_SAVE_PATH: String = "user://chicken_save.tres"
const GAME_SAVE_PATH: String = "user://game_save.tres"

#endregion

#region Enums

#endregion

#region Signals

#endregion

#region Variables

#endregion

#region SAVE AND LOAD
func save_game_data(game_data: GameData):
	if game_data: ResourceSaver.save(game_data, GAME_SAVE_PATH)

func load_game_data() -> GameData:
	var game_data = GameData.new()
	# If file exist then return the existing file
	if ResourceLoader.exists(GAME_SAVE_PATH):
		game_data = ResourceLoader.load(GAME_SAVE_PATH)
		return game_data
	# If file does not exist save and return the default file
	save_game_data(game_data)
	return game_data

func save_chicken_data(chicken_data: ChickenData):
	if chicken_data: ResourceSaver.save(chicken_data, CHICKEN_SAVE_PATH)

func load_chicken_data() -> ChickenData:
	var chicken_data = ChickenData.new()
	# If file exist then return the existing file
	if ResourceLoader.exists(CHICKEN_SAVE_PATH):
		chicken_data = ResourceLoader.load(CHICKEN_SAVE_PATH)
		return chicken_data
	# If file does not exist save and return the default file
	save_chicken_data(chicken_data)
	return chicken_data

#endregion










# END
