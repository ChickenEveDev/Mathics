extends TextureButton

@onready var coop_manager: CoopManager = %CoopManager

func _can_drop_data(_at_position: Vector2, data: Variant) -> bool:
	if data is ItemData and data.category == ItemData.CATEGORY.FOOD and coop_manager.chicken_data.hunger != 0:
		var stock = coop_manager.game_data.food_inventory.get(data.id,0)
		return stock > 0
	return false

func _drop_data(_at_position: Vector2, data: Variant) -> void:
	var current_stock = coop_manager.game_data.food_inventory.get(data.id,0)
	if current_stock > 0:
		coop_manager.game_data.food_inventory[data.id] = current_stock - 1
		coop_manager.chicken_data.feed(data.stat_value)
		GM.save_game_data(coop_manager.game_data)
		coop_manager.update_bottom_bar()
		
		print("Remaining: ", current_stock)
