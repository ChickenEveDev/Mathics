class_name AlgebraGenerator
extends RefCounted







# END
