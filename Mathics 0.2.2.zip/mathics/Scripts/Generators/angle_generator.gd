class_name AngleGenerator
extends RefCounted

const ANGLE_QUESTIONS_FOLDER: String = "res://Resources/AngleQuestions/"

static var game_data: GameData = GM.load_game_data()
static var angle_list: Array[float] = []
static var question_text: String = ""

static func load_all_question_resources() -> void:
	angle_list.clear()
	
	var dir = DirAccess.open(ANGLE_QUESTIONS_FOLDER)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		
		while file_name != "":
			if not dir.current_is_dir() and (file_name.ends_with(".tres") or file_name.ends_with(".remap")):
				var clean_path = ANGLE_QUESTIONS_FOLDER + file_name.replace(".remap", "")
				var resource = ResourceLoader.load(clean_path)
			
				if resource is AngleQuestions:
					angle_list.append(resource.angle)
			
			file_name = dir.get_next()
		dir.list_dir_end()
	else:
		push_error("Failed to access folder at:" + ANGLE_QUESTIONS_FOLDER)

static func generate_angle_payload(choice_count: int = 4) -> Dictionary:
	load_all_question_resources()
	if angle_list.is_empty(): return{}
	
	var target_angle: float = angle_list.pick_random()
	var correct_answer: String = str(int(target_angle)) + "°"
	question_text = str(target_angle)
	
	while game_data.generated_question_list.has(str(target_angle)):
		angle_list.erase(target_angle)
		target_angle = angle_list.pick_random()
		question_text = str(target_angle)
		if angle_list.size() <= 0:
			question_text = "Work in Progress" + str(randf())
			correct_answer = "Work in Progress"
			break

	game_data.generated_question_list.append(question_text)
	GM.save_game_data(game_data)
	
	var distractors: Array[float] = []
	angle_list.shuffle()
	for deg in angle_list:
		if deg != target_angle and not distractors.has(deg):
			distractors.append(deg)
	
	var choices: Array[String] = [correct_answer]
	
	while choices.size() < choice_count and distractors.size() > 0:
		var val = distractors.pop_front()
		choices.append(str(int(val)) + "°")
	
	while choices.size() < choice_count:
		choices.append("N/A")
	choices.shuffle()
	return {
		"question_text" : question_text,
		"correct_answer" : correct_answer,
		"choices" : choices,
		"type" : GameData.TOPIC_LIST.ANGLE,
		"angle_degrees" : target_angle,
	}












# END
