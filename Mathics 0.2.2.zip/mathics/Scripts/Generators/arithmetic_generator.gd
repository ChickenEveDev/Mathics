class_name ArithmeticGenerator
extends RefCounted

#region Constant
const VALUE_RANGE := 15

#endregion
#region Variables
static var game_data: GameData = GM.load_game_data()

#endregion

# Generatoes signed interger arithmetc ( + - * )
static func generate_basic_arithmetic() -> Dictionary:
	var operators := ["+", "-", "*"]
	var op = operators[randi() % operators.size()]
	
	var a = randi_range(-VALUE_RANGE, VALUE_RANGE)
	var b = randi_range(-VALUE_RANGE, VALUE_RANGE)
	
	while a == 0:
		a = randi_range(-VALUE_RANGE, VALUE_RANGE)
	while b == 0:
		b = randi_range(-VALUE_RANGE, VALUE_RANGE)
	
	# Format problem text (handling negative sign with parenthesis)
	var b_str = "(" + str(b) + ")" if b < 0 else str(b)
	var question_text = "%d %s %s = ?" % [a, op, b_str]
	var correct_answer: int = 0
	

	while game_data.generated_question_list.has(question_text):
		op = operators[randi() % operators.size()]
		
		a = randi_range(-VALUE_RANGE, VALUE_RANGE)
		b = randi_range(-VALUE_RANGE, VALUE_RANGE)
		
		while a == 0:
			a = randi_range(-VALUE_RANGE, VALUE_RANGE)
		while b == 0:
			b = randi_range(-VALUE_RANGE, VALUE_RANGE)
		
		# Format problem text (handling negative sign with parenthesis)
		b_str = "(" + str(b) + ")" if b < 0 else str(b)
		question_text = "%d %s %s = ?" % [a, op, b_str]
	
	match op:
		"+": correct_answer = a + b
		"-": correct_answer = a - b
		"*": correct_answer = a * b
	
	game_data.generated_question_list.append(question_text)
	GM.save_game_data(game_data)
	
	return {
		"question_text" : question_text,
		"choices" : generate_distractors(correct_answer),
		"correct_answer" : str(correct_answer),
		"type" : "ARITHMETIC"
	}

static func generate_distractors(correct_answer: int) -> Array:
	var choices = [str(correct_answer)]
	
	# Generate distractors
	var potential_fakes = [
		correct_answer + randi_range(1,3),
		correct_answer - randi_range(1,3),
		correct_answer * -1,
	]
	
	for fake in potential_fakes:
		var fake_str = str(fake)
		if not fake_str in choices and choices.size() < 4:
			choices.append(fake_str)
	
	while choices.size() < 4:
		var dummy = str(correct_answer + randi_range(-10,10))
		if not dummy in choices:
			choices.append(dummy)
	
	choices.shuffle()
	return choices






# END
