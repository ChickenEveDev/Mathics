extends Control

#region Constants
const MAX_QUESTION: int = 10

#endregion

#region Enums

#endregion

#region Signals

#endregion

#region Variables
# Data
var game_data: GameData

# UI References
@onready var question_tracker_label: Label = %QuestionTrackerLabel
@onready var gold_label: Label = %GoldLabel

@onready var question_text: Label = %QuestionText
@onready var question_image: Control = %QuestionImage

@onready var choice_a: Button = %ChoiceA
@onready var choice_b: Button = %ChoiceB
@onready var choice_c: Button = %ChoiceC
@onready var choice_d: Button = %ChoiceD

# Question tracker
var current_question_number: int = 1

#endregion

func _ready() -> void:
	
	game_data = GM.load_game_data()
	
	initialize_top_header()
	
	setup_choice_buttons()

func initialize_top_header():
	gold_label.text = str(game_data.gold)
	question_tracker_label.text = "%s / %s" % [current_question_number, MAX_QUESTION]

#region Question Generator

#endregion

#region Choices
func setup_choice_buttons():
	choice_a.pressed.connect(_on_choice_pressed.bind(choice_a))
	choice_b.pressed.connect(_on_choice_pressed.bind(choice_b))
	choice_c.pressed.connect(_on_choice_pressed.bind(choice_c))
	choice_d.pressed.connect(_on_choice_pressed.bind(choice_d))
	
func _on_choice_pressed(button: Button):
	print(button.name)

#endregion












# END
