class_name ChickenData
extends Resource

signal stats_updated
signal evolved

# Status
const MAX_LEVEL: int = 10
const MAX_HUNGER: int = 100
const MAX_HAPPINESS: int = 100

enum COSMETIC {
	HEAD,
	EYE,
	BEAK,
	BODY,
	CLAW,
	COLOR
}

enum EVOLUTION {
	EGG,
	CHICK,
	CHICKEN
}

# --- CHICKEN STATS ---
# Leveling up
@export var level: int = 0
@export var prestige_count: int = 0

@export var experience: float = 0.0

# Status
@export var is_sick: bool = false
@export var is_dead: bool = false

@export var happiness: float = 100
@export var hunger: float = 0
@export var sickness: float = 0

# --- COSMETICS ---
@export var equipped_cosmetics: Dictionary[COSMETIC, String] = {
	COSMETIC.HEAD: "",
	COSMETIC.EYE: "",
	COSMETIC.BODY: "",
	COSMETIC.BEAK: "",
	COSMETIC.CLAW: "",
	COSMETIC.COLOR: "default"
}

# --- STAT UPDATE ---
func tick_decay(delta: float) -> void:
	if is_dead:
		return
	
	# Passice stat changed over time
	hunger = clamp(hunger + (0.5 * delta), 0.0, 100.0)
	happiness = clamp(happiness - (0.5 * delta), 0.0, 100.0)
	
	# Sickness increase if starving or miserable
	if hunger > 80.0:
		sickness = clamp(sickness + (1.0 * delta), 0.0, 100.0)
	else: # Slowly heal
		sickness = clamp(sickness - (0.2 * delta), 0.0, 100.0)
	
	is_sick = (sickness >= 50.0)
	
	if sickness >= 100:
		is_dead = true
	
	stats_updated.emit()
	

# --- CARE ACTIONS ---
func feed(amount: float) -> void:
	if is_dead: return
	hunger = clamp(hunger - amount, 0.0, 100.0)
	stats_updated.emit()

func play(amount: float) -> void:
	if is_dead: return
	happiness = clamp(happiness + amount, 0.0, 100.0)
	stats_updated.emit()

# --- EVOLUTION SYSTEM ---
func get_evolution_stage() -> EVOLUTION:
	if level == 1:
		return EVOLUTION.EGG
	elif level >= 2 and level <=5:
		return EVOLUTION.CHICK
	else:
		return EVOLUTION.CHICKEN

func add_experience(amount: float) -> void:
	if is_dead: return
	var old_stage: EVOLUTION = get_evolution_stage()
	
	experience += amount
	if experience >= 100.0 and level < MAX_LEVEL:
		experience -= 100
		level += 1
	
	# Check if evolution threshold was crossed
	var new_stage: EVOLUTION = get_evolution_stage()
	if old_stage != new_stage:
		evolved.emit()
	
	stats_updated.emit()

func prestige():
	if level >= 10:
		level = 1
		experience = 0.0
		prestige_count += 1
		stats_updated.emit()
	

#  --- OUTFIT HASH ---
## Returns a unique outfit identifier
func get_outfit_id() -> String:
	return "%s_%s_%s_%s_%s_%s" % [
		equipped_cosmetics[COSMETIC.HEAD],
		equipped_cosmetics[COSMETIC.EYE],
		equipped_cosmetics[COSMETIC.BEAK],
		equipped_cosmetics[COSMETIC.BODY],
		equipped_cosmetics[COSMETIC.CLAW],
		equipped_cosmetics[COSMETIC.COLOR]
	]

# --- HAPPINESS BUFF ---
## Returns a currency multiplier based on the chicken happiness
func get_happiness_multiplier() -> float:
	if happiness >= 80.0:
		return 1.5
	return 1.0













# END
