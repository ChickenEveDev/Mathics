class_name GameData
extends Resource

# --- ANTI-CHEAT ---

# Meta & Safeguards
@export var last_unix_timestamp: int = 0

# --- SETTINGS ---

# Audio
@export var master_volume: float = 1.0
@export var music_volume: float = 0.5
@export var sfx_volume: float = 0.5

# --- ECONOMY ---

# Currencies
@export var gold: int = 67
@export var diamond: int = 0

# --- INVENTORY ---
@export var owned_item_ids: Array[String] = []
@export var food_inventory: Dictionary[String,int] = {}






# END
