class_name CoopManager
extends Node
#BUG
# The item list wouldn't switch
# UPDATE:
# I think I've fixed it now


#region Constants
# Save and Load
const CHICKEN_SAVE_PATH: String = "user://chicken_save.tres"
const GAME_SAVE_PATH: String = "user://game_save.tres"

#endregion

#region Enums

#endregion

#region Signals


#endregion

#region Variables
# Active state variables
var current_category: ItemData.CATEGORY = ItemData.CATEGORY.FOOD
var active_slot_button: Button = null
var current_item_list: Array[ItemData] = []
var selected_item_index: int = 0

var is_sick: bool
var is_dead: bool

var happiness: float
var hunger: float
var sickness: float

# Inventory
var all_database_item: Array[ItemData] = []

# Save and Load
var chicken_data: ChickenData
var game_data: GameData

# Leveling up
var level: int = 0
var experience: float = 0.0

# Status
@onready var chicken_button: TextureButton = %ChickenButton

@onready var decay_timer: Timer = %DecayTimer

@onready var status_popup: Panel = %StatusPopup

@onready var happiness_label: Label = %HappinessLabel
@onready var hunger_label: Label = %HungerLabel
@onready var sickness_label: Label = %SicknessLabel

# UI references
@onready var gold_label: Label = %GoldLabel
@onready var diamond_label: Label = %DiamondLabel

@onready var head_button: Button = %HeadButton
@onready var eye_button: Button = %EyeButton
@onready var beak_button: Button = %BeakButton
@onready var body_button: Button = %BodyButton
@onready var claw_button: Button = %ClawButton
@onready var color_button: Button = %ColorButton

@onready var prev_button: Button = %PrevButton
@onready var next_button: Button = %NextButton
@onready var action_button: Button = %ActionButton
@onready var item_preview: TextureRect = %ItemPreview

#endregion

func _ready() -> void:
	# Load GameData and ChickenData
	load_all_data()
	
	# Load the all database items with the ItemResources folder
	populate_all_database_items()
	
	# Initialize data
	level = chicken_data.level
	experience = chicken_data.experience
	
	is_sick = chicken_data.is_sick
	is_dead = chicken_data.is_dead
	happiness = chicken_data.happiness
	hunger = chicken_data.hunger
	sickness = chicken_data.sickness
	
	setup_slot_buttons()
	
	prev_button.pressed.connect(_on_prev_pressed)
	next_button.pressed.connect(_on_next_pressed)
	action_button.pressed.connect(_on_action_pressed)
	
	switch_category(ItemData.CATEGORY.FOOD)
	
	# Connect hover signals
	chicken_button.mouse_entered.connect(_on_chicken_hovered)
	chicken_button.mouse_exited.connect(_on_chicken_unhovered)
	# Connect pressed signals
	chicken_button.pressed.connect(_on_chicken_pressed)
	
	# Hide status popup by default
	status_popup.visible = false
	


#region Save and Load
func _unhandled_input(event: InputEvent) -> void:
	# If 'R' is pressed then reset the game_data and chicken_data
	if event is InputEventKey and event.pressed and event.keycode == KEY_R:
		DirAccess.remove_absolute(GAME_SAVE_PATH)
		DirAccess.remove_absolute(CHICKEN_SAVE_PATH)
		get_tree().reload_current_scene()

func populate_all_database_items() -> void:
	all_database_item.clear()
	var item_resource_folder_path = "res://Resources/ItemResources/"
	var dir = DirAccess.open(item_resource_folder_path)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		while file_name != "":
			if not dir.current_is_dir() and file_name.ends_with(".tres"):
				var item = ResourceLoader.load(item_resource_folder_path + file_name) as ItemData
				if item:
					all_database_item.append(item)
			file_name = dir.get_next()
		print("Loaded items into database: ", all_database_item.size())

func load_all_data():
	if ResourceLoader.exists(GAME_SAVE_PATH):
		game_data = ResourceLoader.load(GAME_SAVE_PATH)
	else:
		game_data = GameData.new()
		ResourceSaver.save(game_data, GAME_SAVE_PATH)
	
	if ResourceLoader.exists(CHICKEN_SAVE_PATH):
		chicken_data = ResourceLoader.load(CHICKEN_SAVE_PATH)
	else:
		chicken_data = ChickenData.new()
		ResourceSaver.save(chicken_data, CHICKEN_SAVE_PATH)
	
	update_currency_ui()

func save_game_data() -> void:
	if game_data:
		ResourceSaver.save(game_data, GAME_SAVE_PATH)

func save_chicken_data() -> void:
	if chicken_data:
		ResourceSaver.save(chicken_data, CHICKEN_SAVE_PATH)
#endregion

#region UI
func setup_slot_buttons() -> void:
	var slot_map: Dictionary = {
		head_button: ItemData.CATEGORY.HEAD,
		eye_button: ItemData.CATEGORY.EYE,
		beak_button: ItemData.CATEGORY.BEAK,
		body_button: ItemData.CATEGORY.BODY,
		claw_button: ItemData.CATEGORY.CLAW,
		color_button: ItemData.CATEGORY.COLOR,
	}
	
	for button: Button in slot_map.keys():
		button.toggle_mode = false
		button.pressed.connect(_on_slot_button_pressed.bind(button, slot_map[button]))

func _on_slot_button_pressed(clicked_button: Button, category: ItemData.CATEGORY):
	# Untoggling active slot returns to FOOD list
	print("Switched Category: ", category)
	# If button pressed the active button, switch the category to FOOD
	if clicked_button == active_slot_button:
		active_slot_button = null
		switch_category(ItemData.CATEGORY.FOOD)
		return
	
	active_slot_button = clicked_button
	switch_category(category)

func switch_category(category: ItemData.CATEGORY) -> void:
	current_category = category
	selected_item_index = 0
	
	current_item_list.clear()
	for item in all_database_item:
		if item.category == category:
			current_item_list.append(item)
	
	update_bottom_bar()

func update_bottom_bar() -> void:
	if current_item_list.is_empty():
		item_preview.texture = null
		action_button.text = "NONE"
		action_button.disabled = true
		return
	
	action_button.disabled = false
	var active_item: ItemData = current_item_list[selected_item_index]
	item_preview.texture = active_item.icon
	
	if current_category == ItemData.CATEGORY.FOOD:
		# Food Logic
		var stock_count: int = game_data.food_inventory.get(active_item.id, 0)
		action_button.text = "Buy (%d G) [Stock: %d]" % [active_item.price_gold, stock_count]
	else:
		# Cosmetic Logic
		var is_owned: bool = game_data.owned_item_ids.has(active_item.id)
		var is_equipped = chicken_data.equipped_cosmetics.get(current_category) == active_item.id
		
		if is_equipped:
			action_button.text = "Equipped"
		elif is_owned:
			action_button.text = "Equip"
		else:
			action_button.text = "Buy (%d D)" % active_item.price_diamond

func _on_prev_pressed() -> void:
	if current_item_list.is_empty(): return
	selected_item_index = (selected_item_index - 1 + current_item_list.size()) % current_item_list.size()
	update_bottom_bar()

func _on_next_pressed() -> void:
	if current_item_list.is_empty(): return
	selected_item_index = (selected_item_index + 1) % current_item_list.size()
	update_bottom_bar()

func _on_action_pressed() -> void:
	if current_item_list.is_empty(): return
	
	var active_item: ItemData = current_item_list[selected_item_index]
	
	# - Purchase Logic -
	
	# For food
	if current_category == ItemData.CATEGORY.FOOD:
		if game_data.gold >= active_item.price_gold:
			game_data.gold -= active_item.price_gold
			
			var current_stock = game_data.food_inventory.get(active_item.id, 0)
			game_data.food_inventory[active_item.id] = current_stock + 1
			
			save_game_data()
			update_currency_ui()
			update_bottom_bar()
		return
	
	# For Cosmetics
	
	var is_owned: bool = game_data.owned_item_ids.has(active_item.id)
	if not is_owned:
		if game_data.diamond >= active_item.price_diamond:
			game_data.diamond -= active_item.price_diamond
			game_data.owned_item_ids.append(active_item.id)
			save_game_data()
			update_currency_ui()
			update_bottom_bar()
		return
	
	# Equip cosmetics
	chicken_data.equipped_cosmetics[current_category] = active_item.id
	save_chicken_data()
	update_bottom_bar()

func update_currency_ui():
	gold_label.text = str(game_data.gold)
	diamond_label.text = str(game_data.diamond)

func _on_chicken_hovered() -> void:
	# Update the text
	happiness_label.text = "Happiness: " + str(chicken_data.happiness)
	hunger_label.text = "Hunger: " + str(chicken_data.hunger)
	sickness_label.text = "Sickness: " + str(chicken_data.sickness)
	
	# Show the popup
	status_popup.show()

func _on_chicken_unhovered() -> void:
	# Hide the popup
	status_popup.hide()

func _on_chicken_pressed() -> void:
	# Toggle visibility
	status_popup.visible = not status_popup.visible
	
	# Update the text
	if status_popup.visible:
		happiness_label.text = "Happiness: " + str(chicken_data.happiness)
		hunger_label.text = "Hunger: " + str(chicken_data.hunger)
		sickness_label.text = "Sickness: " + str(chicken_data.sickness)
	

#endregion






# END
