extends TextureRect


#BUG
# Working on the HOVER and UNHOVER of item preview
#TASK
# Disable item tool tip while dragging

const SPRITE_SIZE := 48

@onready var coop_manager: CoopManager = %CoopManager
@onready var item_tool_tip_popup: Panel = %ItemToolTipPopup
@onready var item_name_label: Label = %ItemNameLabel
@onready var item_value_label: Label = %ItemValueLabel

func _ready() -> void:
	item_tool_tip_popup.mouse_entered.connect(_on_preview_hovered)
	item_tool_tip_popup.mouse_exited.connect(_on_preview_unhovered)

func _on_preview_hovered():
	if coop_manager.current_item_list.is_empty(): return
	
	item_tool_tip_popup.visible = true
	var active_item: ItemData = coop_manager.current_item_list[coop_manager.selected_item_index]
	
	if item_tool_tip_popup.visible:
		item_name_label.text = active_item.name
		if coop_manager.current_category == ItemData.CATEGORY.FOOD:
			item_value_label.text = "-%d Hunger" % active_item.stat_value
		else:
			item_value_label.text = "Cosmetic Item"

func _on_preview_unhovered():
	item_tool_tip_popup.visible = false

func _gui_input(event: InputEvent) -> void:
	if (event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT) \
	or (event is InputEventScreenTouch and event.pressed):
		toggle_tooltip()

func toggle_tooltip() -> void:
	if coop_manager.current_item_list.is_empty(): return
	
	var active_item: ItemData = coop_manager.current_item_list[coop_manager.selected_item_index]
	item_tool_tip_popup.visible = not item_tool_tip_popup.visible
	
	if item_tool_tip_popup.visible:
		item_name_label.text = active_item.name
		if coop_manager.current_category == ItemData.CATEGORY.FOOD:
			item_value_label.text = "-%d Hunger" % active_item.stat_value
		else:
			item_value_label.text = "Cosmetic Item"

func _get_drag_data(_at_position: Vector2) -> Variant:
	# Only allow food
	if coop_manager.current_category != ItemData.CATEGORY.FOOD or texture == null:
		return
	
	# Get current selected item
	var active_item = coop_manager.current_item_list[coop_manager.selected_item_index]
	# Check the player's stock
	var stock = coop_manager.game_data.food_inventory.get(active_item.id, 0)
	
	if stock <= 0:
		print("Out of stock! Can't drag")
		return null
	
	# Create a wrapper
	var wrapper: Control = Control.new()
	
	# Create a visual preview
	var preview = TextureRect.new()
	preview.texture = texture
	preview.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	preview.custom_minimum_size = Vector2(SPRITE_SIZE, SPRITE_SIZE)
	
	# Offset by negative half
	@warning_ignore("integer_division")
	preview.position = -Vector2(SPRITE_SIZE/2, SPRITE_SIZE/2)
	
	wrapper.add_child(preview)
	set_drag_preview(wrapper)
	
	return active_item
	
