extends Node

#region Constants
const GAME_SAVE_PATH: String = "user://game_save.tres"

#endregion

#region Enums

#endregion

#region Signals

#endregion

#region Variables
# Main Title UI
@onready var enter_button: Button = %EnterButton
@onready var option_button: Button = %OptionButton
@onready var quit_button: Button = %QuitButton

@onready var cheat_warning_label: Label = %CheatWarningLabel
# Pet preview thing

# Option Overlay UI
@onready var option_overlay: ColorRect = %OptionOverlay

@onready var close_button: Button = %CloseButton

@onready var master_volume_h_slider: HSlider = %MasterVolumeHSlider
@onready var music_volume_h_slider: HSlider = %MusicVolumeHSlider
@onready var sfx_volume_h_slider: HSlider = %SFXVolumeHSlider

var game_data: GameData

#endregion

func _ready() -> void:
	# UI signals
	enter_button.pressed.connect(_on_enter_pressed)
	option_button.pressed.connect(_on_option_pressed)
	quit_button.pressed.connect(_on_quit_pressed)
	
	close_button.pressed.connect(_on_close_pressed)
	
	# Slider signals
	master_volume_h_slider.value_changed.connect(_on_master_volume_changed)
	music_volume_h_slider.value_changed.connect(_on_music_volume_changed)
	sfx_volume_h_slider.value_changed.connect(_on_sfx_volume_changed)
	
	option_overlay.visible = false
	cheat_warning_label.text = ""
	
	_initialize_game_state()
	
	if game_data.is_first_time:
		_initialize_tutorial()

func _initialize_tutorial() -> void:
	# Program the tutorial here
	pass

func _initialize_game_state():
	if ResourceLoader.exists(GAME_SAVE_PATH):
		game_data = ResourceLoader.load(GAME_SAVE_PATH) as GameData
	else:
		game_data = GameData.new()
		ResourceSaver.save(game_data, GAME_SAVE_PATH)
	
	# Update sliders from saved data
	master_volume_h_slider.value = game_data.master_volume
	music_volume_h_slider.value = game_data.music_volume
	sfx_volume_h_slider.value = game_data.sfx_volume
	
	# Apply initial audio bus volumes
	set_bus_volume("Master", game_data.master_volume)
	set_bus_volume("Music", game_data.music_volume)
	set_bus_volume("SFX", game_data.sfx_volume)
	
	print("TitleManager: ", master_volume_h_slider.value)
	
	# Anti-cheat
	var current_time: int = int(Time.get_unix_time_from_system())
	if current_time < game_data.last_unix_timestamp:
		cheat_warning_label.text = "SYSTEM TIME ERROR! Fix clock to play"
		enter_button.disabled = true
	else:
		game_data.last_unix_timestamp = current_time
		ResourceSaver.save(game_data, GAME_SAVE_PATH)

#region Navigation
func _on_enter_pressed():
	# Change scene to Coop Scene
	get_tree().change_scene_to_file("uid://cjrep2njhgeiq")

func _on_option_pressed():
	option_overlay.visible = true

func _on_quit_pressed():
	get_tree().quit()

func _on_close_pressed():
	option_overlay.visible = false
	ResourceSaver.save(game_data, GAME_SAVE_PATH)

#endregion

#region Audio
func set_bus_volume(bus_name: String, value: float) -> void:
	var bus_index = AudioServer.get_bus_index(bus_name)
	if bus_index != 1:
		AudioServer.set_bus_volume_db(bus_index, linear_to_db(value))

func _on_master_volume_changed(value: float) -> void:
	game_data.master_volume = value
	set_bus_volume("Master", value)

func _on_music_volume_changed(value: float) -> void:
	game_data.music_volume = value
	set_bus_volume("Music", value)

func _on_sfx_volume_changed(value: float) -> void:
	game_data.sfx_volume = value
	set_bus_volume("SFX", value)


#endregion





# END
