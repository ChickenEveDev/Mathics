extends Control

#region Constants
const MAX_QUESTION: int = 10

const MIN_FONT_SIZE: int = 128
const MAX_FONT_SIZE: int = 16

#endregion

#region Enums

#endregion

#region Signals

#endregion

#region Variables
# Data
var game_data: GameData

# UI References
@onready var question_tracker_label: Label = %QuestionTrackerLabel
@onready var gold_label: Label = %GoldLabel

@onready var question_text: Label = %QuestionText
@onready var question_image: Control = %QuestionImage

@onready var choice_a: Button = %ChoiceA
@onready var choice_b: Button = %ChoiceB
@onready var choice_c: Button = %ChoiceC
@onready var choice_d: Button = %ChoiceD

# Question
var topic_selected: GameData.TOPIC_LIST

var current_question_number: int = 1
var correct_answer: String = ""

var correct_answer_counter: int = 0

var all_concept_banks: Dictionary = {}
var active_category_dict: Dictionary = {}

#endregion

func _ready() -> void:
	game_data = GM.load_game_data()
	
	_initialize_top_header()
	_initialize_question_text()
	
	setup_choice_buttons()
	
	all_concept_banks = ConceptGenerator.load_all_question_resources()
	
	load_next_question()

#region Question Generator
#region ARITHMETIC
func load_next_question() -> void:
	var new_question: Dictionary
	
	# Topic selected will be just I dunno added here?
	match topic_selected:
		GameData.TOPIC_LIST.ARITHMETIC:
			new_question = ArithmeticGenerator.generate_basic_arithmetic()
		GameData.TOPIC_LIST.CONCEPT:
			# SET THIS CHICKEN NUGGY, FOR WHATEVER CATEGORY OF CONCEPT THEY WANT. I dunno if random or selected -_-
			select_topic(ConceptData.CATEGORY.ANGLES)
			new_question = ConceptGenerator.generate_concept_payload(active_category_dict)
	
	if new_question.is_empty():
		print("No available question!")
		return
	
	display_question(new_question)

#endregion
#region CONCEPT
func select_topic(selected_category: ConceptData.CATEGORY) -> void:
	active_category_dict = all_concept_banks.get(selected_category,{})

#endregion
#endregion

#region UI
func _initialize_top_header():
	gold_label.text = str(game_data.gold)
	question_tracker_label.text = "%s / %s" % [current_question_number, MAX_QUESTION]

func display_question(new_question):
	# new_question = { "question_text", "choices", "correct_answer", "type" }
	set_question_text(new_question["question_text"])
	choice_a.text = new_question["choices"][0]
	choice_b.text = new_question["choices"][1]
	choice_c.text = new_question["choices"][2]
	choice_d.text = new_question["choices"][3]
	correct_answer = new_question["correct_answer"]
	question_tracker_label.text = "%s / %s" % [current_question_number, MAX_QUESTION]

func setup_choice_buttons():
	choice_a.pressed.connect(_on_choice_pressed.bind(choice_a))
	choice_b.pressed.connect(_on_choice_pressed.bind(choice_b))
	choice_c.pressed.connect(_on_choice_pressed.bind(choice_c))
	choice_d.pressed.connect(_on_choice_pressed.bind(choice_d))
	
func _on_choice_pressed(button: Button):
	current_question_number += 1
	
	if button.text == correct_answer:
		correct_answer_counter += 1

	if current_question_number <= MAX_QUESTION:
		load_next_question()
	else:
		# Change to result scene
		get_tree().change_scene_to_file("uid://5q1rgn0x57hu")

# --- QUESTION LABEL ---
func set_question_text(new_text: String) -> void:
	question_text.text = new_text
	_adjust_font_size()

func _initialize_question_text() -> void:
	# TEMPORARY: Randomly select what the quiz will be
	topic_selected = [GameData.TOPIC_LIST.ARITHMETIC,GameData.TOPIC_LIST.CONCEPT].pick_random()
	question_text.resized.connect(_adjust_font_size)
	question_text.item_rect_changed.connect(_adjust_font_size)

func _adjust_font_size() -> void:
	# Checks if there is anything on the question text
	if question_text.text.is_empty() or question_text.size.x <= 0 or question_text.size.y <= 0:
		return
	
	var font = question_text.get_theme_font("font")
	var font_size = MAX_FONT_SIZE
	
	# Decrease the font size till it fits
	while font_size > MIN_FONT_SIZE:
		var text_size = font.get_string_size(question_text.text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
		if text_size.x <= question_text.size.x and text_size.y <= question_text.size.y:
			break
		font_size -= 1
	
	question_text.add_theme_font_size_override("font_size", font_size)

#endregion

















# END
