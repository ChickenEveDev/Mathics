class_name ConceptGenerator
extends RefCounted

#region Constants
const CONCEPT_FOLDER_PATH: String = "res://Resources/QuestionResources/"

#endregion

#region Variables


#endregion

static func load_all_question_resources() -> Dictionary:
	var category_dictionaries: Dictionary = {}
	
	for cat in ConceptData.CATEGORY.values():
		category_dictionaries[cat] = {}
	
	var dir = DirAccess.open(CONCEPT_FOLDER_PATH)
	if dir:
		dir.list_dir_begin()
		var file_name = dir.get_next()
		
		while file_name != "":
			if not dir.current_is_dir() and (file_name.ends_with(".tres") or file_name.ends_with(".remap")):
				var clean_path = CONCEPT_FOLDER_PATH + file_name.replace(".remap", "")
				var resource = ResourceLoader.load(clean_path)
			
				if resource is ConceptData:
					category_dictionaries[resource.category][resource.question] = resource.answer
			
			file_name = dir.get_next()
		dir.list_dir_end()
	else:
		push_error("Failed to access folder at:" + CONCEPT_FOLDER_PATH)
	
	return category_dictionaries

static func generate_concept_payload(concept_dict: Dictionary, choice_count: int = 4) -> Dictionary:
	if concept_dict.is_empty(): return {}
	
	var question_list = concept_dict.keys()
	var random_question = question_list.pick_random()
	var correct_answer = concept_dict[random_question]
	
	# Fetch potential distractors
	var category_answers = concept_dict.values()
	var distractors: Array = []
	
	for ans in category_answers:
		if ans != correct_answer and not distractors.has(ans):
			distractors.append(ans)
	
	distractors.shuffle()
	
	# Build option pool
	var choices: Array[String] = [correct_answer]
	while choices.size() < choice_count and distractors.size() > 0:
		choices.append(distractors.pop_front())
	
	# Fallback if dictionary lacks enough unique answers
	while choices.size() < choice_count:
		choices.append("N/A")
	
	choices.shuffle()
	
	return {
		"question_text": random_question,
		"correct_answer": correct_answer,
		"choices": choices
	}















# END
