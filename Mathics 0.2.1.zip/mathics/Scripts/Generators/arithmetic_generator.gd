class_name ArithmeticGenerator
extends RefCounted

const VALUE_RANGE := 15

# Generatoes signed interger arithmetc ( + - * )
static func generate_basic_arithmetic() -> Dictionary:
	var operators := ["+", "-", "*"]
	var op = operators[randi() % operators.size()]
	
	var a = randi_range(-VALUE_RANGE, VALUE_RANGE)
	var b = randi_range(-VALUE_RANGE, VALUE_RANGE)
	
	# Avoid multiplying with zero
	if op == "*" and b == 0:
		b = randi_range(1,15)
	
	var correct_answer: int = 0
	match op:
		"+": correct_answer = a + b
		"-": correct_answer = a - b
		"*": correct_answer = a * b
	
	# Format problem text (handling negative sign with parenthesis)
	var b_str = "(" + str(b) + ")" if b < 0 else str(b)
	var question_text = "%d %s %s = ?" % [a, op, b_str]
	
	return {
		"question_text" : question_text,
		"choices" : generate_distractors(correct_answer),
		"correct_answer" : str(correct_answer),
		"type" : "ARITHMETIC"
	}

static func generate_distractors(correct_answer: int) -> Array:
	var choices = [str(correct_answer)]
	
	# Generate distractors
	var potential_fakes = [
		correct_answer + randi_range(1,3),
		correct_answer - randi_range(1,3),
		correct_answer * -1,
	]
	
	for fake in potential_fakes:
		var fake_str = str(fake)
		if not fake_str in choices and choices.size() < 4:
			choices.append(fake_str)
	
	while choices.size() < 4:
		var dummy = str(correct_answer + randi_range(-10,10))
		if not dummy in choices:
			choices.append(dummy)
	
	choices.shuffle()
	return choices






# END
