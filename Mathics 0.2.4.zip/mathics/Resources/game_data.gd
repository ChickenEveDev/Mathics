class_name GameData
extends Resource

# --- FIRST TIME ---
@export var is_first_time: bool = true

# --- ANTI-CHEAT ---

# Meta & Safeguards
@export var last_unix_timestamp: int = 0

# --- SETTINGS ---

# Audio
@export var master_volume: float = 1.0
@export var music_volume: float = 0.5
@export var sfx_volume: float = 0.5

# --- ECONOMY ---

# Currencies
@export var gold: int = 67
@export var diamond: int = 0

# --- INVENTORY ---
@export var owned_item_ids: Array[String] = []

# --- QUESTIONS ---
@export var generated_question_list: Array[String] = [] ## Stores all question generated during a quiz session with the soul purpose to prevent copies

# --- ... ---
@export var competency_tier: Dictionary[GM.TOPIC, GM.MASTERY_TIER] = {
	GM.TOPIC.UNIT_CONVERSION: GM.MASTERY_TIER.SILVER,
	GM.TOPIC.PYRAMID_VOLUME: GM.MASTERY_TIER.SILVER,
	GM.TOPIC.CYLINDER_VOLUME: GM.MASTERY_TIER.SILVER,
	GM.TOPIC.PERCENTILE_CHANGES: GM.MASTERY_TIER.SILVER,
	GM.TOPIC.FINANCIAL_LITERACY: GM.MASTERY_TIER.SILVER,
	GM.TOPIC.SPEED_RATE: GM.MASTERY_TIER.SILVER,
	GM.TOPIC.POLYGON_PROPERTIES: GM.MASTERY_TIER.SILVER,
	GM.TOPIC.ANGLE: GM.MASTERY_TIER.SILVER,
}










# END
