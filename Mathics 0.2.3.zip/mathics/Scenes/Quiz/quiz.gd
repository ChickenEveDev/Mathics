extends Control

# BUG HUNTING

# Gabillion bugs HAHAHHA

#region Constants
const MAX_QUESTION: int = 10

const MIN_FONT_SIZE: int = 128
const MAX_FONT_SIZE: int = 16

#endregion

#region Enums

#endregion

#region Signals

#endregion

#region Variables
# Data
var game_data: GameData

# UI References
@onready var question_tracker_label: Label = %QuestionTrackerLabel
@onready var gold_label: Label = %GoldLabel

@onready var question_container: PanelContainer = %QuestionContainer
@onready var question_text: Label = %QuestionText
@onready var question_image: Control = %QuestionImage

@onready var choice_a: Button = %ChoiceA
@onready var choice_b: Button = %ChoiceB
@onready var choice_c: Button = %ChoiceC
@onready var choice_d: Button = %ChoiceD

# Question
var topic_selected: GameData.TOPIC_LIST

var current_question_number: int = 1
var correct_answer: String = ""

var correct_answer_counter: int = 0

var all_concept_banks: Dictionary = {}
var active_category_dict: Dictionary = {}

#endregion

func _ready() -> void:
	game_data = GM.load_game_data()
	
	await question_container.sort_children
	all_concept_banks = ConceptGenerator.load_all_question_resources()
	
	_initialize_top_header()
	_initialize_question_text()
	
	setup_choice_buttons()
	
	load_next_question()

#region Question Generator
#region ARITHMETIC
func load_next_question() -> void:
	var new_question: Dictionary
	
	match topic_selected:
		GameData.TOPIC_LIST.ARITHMETIC:
			new_question = ArithmeticGenerator.generate_basic_arithmetic()
		GameData.TOPIC_LIST.CONCEPT:
			# SET THIS CHICKEN NUGGY, FOR WHATEVER CATEGORY OF CONCEPT THEY WANT. I dunno if random or selected -_-
			select_topic(ConceptQuestion.CATEGORY.ANGLES)
			new_question = ConceptGenerator.generate_concept_payload(active_category_dict)
		GameData.TOPIC_LIST.ANGLE:
			new_question = AngleGenerator.generate_angle_payload()
		GameData.TOPIC_LIST.ALGEBRA:
			@warning_ignore("int_as_enum_without_cast")
			var sub_type : AlgebraGenerator.SUB_TYPE = randi_range(0, AlgebraGenerator.SUB_TYPE.size() - 1)
			new_question = AlgebraGenerator.generate_algebra_expression(sub_type)
	
	if new_question.is_empty():
		load_next_question()
		return
	
	display_question(new_question)

#endregion
#region CONCEPT
func select_topic(selected_category: ConceptQuestion.CATEGORY) -> void:
	active_category_dict = all_concept_banks.get(selected_category,{})

#endregion
#region ANGLES
var angle_degrees: float

func set_angle(degrees: float) -> void:
	angle_degrees = degrees
	queue_redraw()

func _draw() -> void:
	match topic_selected:
		GameData.TOPIC_LIST.ANGLE:
			if angle_degrees == 0.0: return
			
			var center: Vector2 = question_container.get_global_transform().origin + (question_container.size / 2.0)
			var line_length: float = 110.0
			var line_width: float = 2.0
			
			var guide_line_color: Color = Color(1,1,1,0.25)
			var guide_line_width: float = 1.5
			var guide_tick_color: Color = Color(1,1,1, 0.4)
			var guide_tick_width: float = 1.0
			
			# I. Draw 360-degrees guide lines
			for deg in range(0, 360, 30):
				var guide_rad: float = deg_to_rad(-deg)
				var guide_end: Vector2 = center + Vector2(cos(guide_rad), sin(guide_rad)) * line_length
				
				draw_line(center, guide_end, guide_line_color, guide_line_width)
				
			
			# II. Draw 15-degrees tick marks along the circle edge
			var inner_tick_radius: float = line_length - 8.0
			for deg in range(0, 360, 15):
				if deg % 30 == 0:
					continue
				
				var tick_rad: float = deg_to_rad(-deg)
				var tick_start: Vector2 = center + Vector2(cos(tick_rad), sin(tick_rad)) * inner_tick_radius
				var tick_end: Vector2 = center + Vector2(cos(tick_rad), sin(tick_rad)) * line_length
				
				draw_line(tick_start, tick_end, guide_tick_color, guide_tick_width)
			
			# III. Draw outer boundary
			draw_arc(center, line_length, 0.0, TAU, 64, Color(1,1,1,0.5), line_width)
			
			# IV. Draw the actual angle rays
			var ray1: Vector2 = center + Vector2(line_length, 0)
			var target_rad: float = deg_to_rad(-angle_degrees)
			var ray2: Vector2 = center + Vector2(cos(target_rad), sin(target_rad)) * line_length
			
			# Highlighted angle arms
			draw_line(center, ray1, Color.WHITE, line_width * 2)
			draw_line(center, ray2, Color.WHITE, line_width * 2)
			
			# Draw arc indicator
			draw_arc(center, 35, 0.0, target_rad, 32, Color.DEEP_SKY_BLUE, 2.5, true)
			
			# Center Vertex Point
			draw_circle(center, 5.0, Color.YELLOW)
			

#endregion
#endregion

#region UI
func _initialize_top_header():
	gold_label.text = str(game_data.gold)
	question_tracker_label.text = "%s / %s" % [current_question_number, MAX_QUESTION]

func display_question(new_question):
	# new_question = { "question_text", "choices", "correct_answer", "type"}
	set_question_text(new_question["question_text"])
	if new_question["type"] == GameData.TOPIC_LIST.ANGLE:
		set_angle(new_question["angle_degrees"])
	
	choice_a.text = new_question["choices"][0]
	choice_b.text = new_question["choices"][1]
	choice_c.text = new_question["choices"][2]
	choice_d.text = new_question["choices"][3]
	correct_answer = new_question["correct_answer"]
	question_tracker_label.text = "%s / %s" % [current_question_number, MAX_QUESTION]

func setup_choice_buttons():
	choice_a.pressed.connect(_on_choice_pressed.bind(choice_a))
	choice_b.pressed.connect(_on_choice_pressed.bind(choice_b))
	choice_c.pressed.connect(_on_choice_pressed.bind(choice_c))
	choice_d.pressed.connect(_on_choice_pressed.bind(choice_d))
	
func _on_choice_pressed(button: Button):
	current_question_number += 1
	
	if button.text == correct_answer:
		correct_answer_counter += 1

	if current_question_number <= MAX_QUESTION:
		load_next_question()
	else:
		# Change to result scene
		get_tree().change_scene_to_file("uid://5q1rgn0x57hu")

# --- QUESTION LABEL ---
func set_question_text(new_text: String) -> void:
	question_text.text = new_text
	_adjust_font_size()

func _initialize_question_text() -> void:
	# TEMPORARY: Randomly select what the quiz will be
	@warning_ignore("int_as_enum_without_cast")
	topic_selected = randi_range(0, GameData.TOPIC_LIST.size() - 1)
	question_text.resized.connect(_adjust_font_size)
	question_text.item_rect_changed.connect(_adjust_font_size)

func _adjust_font_size() -> void:
	# Checks if there is anything on the question text
	if question_text.text.is_empty() or question_text.size.x <= 0 or question_text.size.y <= 0:
		return
	
	var font = question_text.get_theme_font("font")
	var font_size = MAX_FONT_SIZE
	
	# Decrease the font size till it fits
	while font_size > MIN_FONT_SIZE:
		var text_size = font.get_string_size(question_text.text, HORIZONTAL_ALIGNMENT_CENTER, -1, font_size)
		if text_size.x <= question_text.size.x and text_size.y <= question_text.size.y:
			break
		font_size -= 1
	
	question_text.add_theme_font_size_override("font_size", font_size)

#endregion

















# END
