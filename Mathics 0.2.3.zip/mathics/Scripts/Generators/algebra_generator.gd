class_name AlgebraGenerator
extends RefCounted

enum SUB_TYPE {
	SUBSTITUTION,
	MONOMIAL_X_BINOMIAL,
	BINOMIAL_X_BINOMIAL
}

static func generate_algebra_expression(sub_type: int, choice_count: int = 4) -> Dictionary:
	match sub_type:
		SUB_TYPE.SUBSTITUTION:
			return _generate_substitution(choice_count)
		SUB_TYPE.MONOMIAL_X_BINOMIAL:
			return _generate_monomial_x_binomial(choice_count)
		SUB_TYPE.BINOMIAL_X_BINOMIAL:
			return _generate_binomial_x_binomial(choice_count)
		_:
			push_error("Invalid sub_type provided.")
			return {}

static func _generate_substitution(choice_count: int = 4) -> Dictionary:
	var a = _rand_nonzero_int(-6, 6)
	var b = _rand_nonzero_int(-10, 10)
	var x_val = _rand_nonzero_int(-5, 5)

	var correct_num = (a * x_val) + b
	var correct_ans = str(correct_num)

	var b_str = ("+ " if b > 0 else "- ") + str(abs(b))
	var a_str = _format_coeff(a)
	var question_text = "Evaluate the expression: " + a_str + "x " + b_str + " for x = " + str(x_val)

	# Common student distractors
	var distractors = [
		# Added coefficient instead of multiplying
		str(a + x_val + b),
		# Sign error on multiplication
		str((-a * x_val) + b),
		# Sign error on constant
		str((a * x_val) - b),
		# Off by a small amount
		str(correct_num + _rand_nonzero_int(-2, 2)),
		# Random incorrect answer
		str(_rand_nonzero_int(-20, 20))
	]

	var choices = _assemble_choices(correct_ans, distractors, choice_count)

	return {
		"question_text": question_text,
		"choices": choices,
		"correct_answer": correct_ans,
		"type": GameData.TOPIC_LIST.ALGEBRA,
		"sub_type": SUB_TYPE.SUBSTITUTION,
		"explanation_steps": [
			"1. Substitute x = " + str(x_val) + " into the expression.",
			"2. Calculate " + str(a) + " * " + str(x_val) + " = " + str(a * x_val) + ".",
			"3. Add " + str(a * x_val) + " and " + str(b) + " to get " + str(correct_num) + ".",
			"4. The final answer is " + str(correct_num) + "."
		]
	}

static func _generate_monomial_x_binomial(choice_count: int = 4) -> Dictionary:
	var a = _rand_nonzero_int(-5, 5)
	var c = _rand_nonzero_int(-9, 9)

	# Fix: The monomial x binomial expression is a*(x + c) = ax + ac
	var term1_coef = a
	var term2_coef = a * c

	var correct_answer = _format_binomial(term1_coef, term2_coef)

	var c_str = ("+ " if c > 0 else "- ") + str(abs(c))
	var question_text = "Expand the expression: " + str(a) + "(x " + c_str + ")"

	# Common student distractors
	var distractors = [
		# Sign error on first term
		_format_binomial(-term1_coef, term2_coef),
		# Sign error on second term
		_format_binomial(term1_coef, -term2_coef),
		# Both terms with sign errors
		_format_binomial(-term1_coef, -term2_coef),
		# Distributed first term only (forgot to multiply second term)
		_format_binomial(term1_coef, c),
		# Added instead of multiplying
		_format_binomial(a + 1, a + c),
		# Off by a small amount
		_format_binomial(term1_coef, term2_coef + _rand_nonzero_int(-2, 2))
	]

	var choices = _assemble_choices(correct_answer, distractors, choice_count)

	return {
		"question_text": question_text,
		"choices": choices,
		"correct_answer": correct_answer,
		"type": GameData.TOPIC_LIST.ALGEBRA,
		"sub_type": SUB_TYPE.MONOMIAL_X_BINOMIAL,
		"explanation_steps": [
			"1. Distribute " + str(a) + " to both terms inside the parentheses.",
			"2. Calculate " + str(a) + " * x = " + _format_binomial(term1_coef, 0) + ".",
			"3. Calculate " + str(a) + " * " + str(c) + " = " + str(term2_coef) + ".",
			"4. Combine the results to get " + correct_answer + "."
		]
	}

static func _generate_binomial_x_binomial(choice_count: int = 4) -> Dictionary:
	var a = _rand_nonzero_int(-8, 8)
	var b = _rand_nonzero_int(-8, 8)

	var middle_coef = a + b
	var last_const = a * b

	var correct_answer = _format_trinomial(1, middle_coef, last_const)

	var a_str = ("+ " if a > 0 else "- ") + str(abs(a))
	var b_str = ("+ " if b > 0 else "- ") + str(abs(b))
	var question_text = "Expand the expression: (x " + a_str + ")(x " + b_str + ")"

	# Common student distractors
	var distractors = [
		# Sign error on middle term
		_format_trinomial(1, -middle_coef, last_const),
		# Sign error on last term
		_format_trinomial(1, middle_coef, -last_const),
		# Both terms with sign errors
		_format_trinomial(1, -middle_coef, -last_const),
		# Forgot last constant term
		_format_trinomial(1, middle_coef, 0),
		# Added instead of multiplying for constant
		_format_trinomial(1, middle_coef, a + b),
		# Off by a small amount
		_format_trinomial(1, middle_coef, last_const + _rand_nonzero_int(-2, 2))
	]

	var choices = _assemble_choices(correct_answer, distractors, choice_count)

	return {
		"question_text": question_text,
		"choices": choices,
		"correct_answer": correct_answer,
		"type": GameData.TOPIC_LIST.ALGEBRA,
		"sub_type": SUB_TYPE.BINOMIAL_X_BINOMIAL,
		"explanation_steps": [
			"1. Use the distributive property (FOIL method) to expand the expression.",
			"2. Multiply the first terms: x * x = x².",
			"3. Multiply the outer terms: x * " + str(b) + " = " + _format_coeff(b) + "x.",
			"4. Multiply the inner terms: " + str(a) + " * x = " + _format_coeff(a) + "x.",
			"5. Multiply the last terms: " + str(a) + " * " + str(b) + " = " + str(last_const) + ".",
			"6. Combine like terms: " + _format_coeff(b) + "x + " + _format_coeff(a) + "x = " + _format_coeff(middle_coef) + "x.",
			"7. The final answer is " + correct_answer + "."
		]
	}

# Helper Functions

static func _rand_nonzero_int(min_: int, max_: int) -> int:
	var num = randi() % (max_ - min_ + 1) + min_
	return num if num != 0 else _rand_nonzero_int(min_, max_)

static func _assemble_choices(correct_answer: String, distractors: Array, choice_count: int) -> Array:
	var choices: Array = [correct_answer]
	
	for d in distractors:
		if choices.size() >= choice_count:
			break
		# Ensure unique options only and don't re-add the correct answer
		if not choices.has(d):
			choices.append(d)
			
	# If we still lack choices due to duplicate distractors, generate random fallbacks
	var attempts = 0
	while choices.size() < choice_count and attempts < 20:
		attempts += 1
		var dummy = str(_rand_nonzero_int(-30, 30))
		if not choices.has(dummy):
			choices.append(dummy)

	choices.shuffle()
	return choices

static func _format_coeff(coeff: int) -> String:
	if coeff == 1:
		return ""
	elif coeff == -1:
		return "-"
	return str(coeff)

static func _format_binomial(term1: int, term2: int) -> String:
	if term1 == 0 and term2 == 0:
		return "0"

	var term1_str = _format_coeff(term1) + "x" if term1 != 0 else ""
	var term2_str = ""

	if term2 != 0:
		if term1 != 0:
			term2_str = (" + " if term2 > 0 else " - ") + str(abs(term2))
		else:
			term2_str = str(term2)

	return term1_str + term2_str

static func _format_trinomial(coef_x2: int, coef_x: int, constant: int) -> String:
	if coef_x2 == 0 and coef_x == 0 and constant == 0:
		return "0"

	var x2_str = _format_coeff(coef_x2) + "x²" if coef_x2 != 0 else ""
	var x_str = ""
	if coef_x != 0:
		var sign_str = " + " if coef_x > 0 else " - "
		x_str = sign_str + ("" if abs(coef_x) == 1 else str(abs(coef_x))) + "x"
		
	var const_str = (" + " if constant > 0 else " - ") + str(abs(constant)) if constant != 0 else ""
	
	# Handle cases where x2_str might be empty to prevent leading ' + '
	var result = x2_str + x_str + const_str
	if result.begins_with(" + "):
		result = result.substr(3)
	elif result.begins_with(" - "):
		result = "-" + result.substr(3)
		
	return result
